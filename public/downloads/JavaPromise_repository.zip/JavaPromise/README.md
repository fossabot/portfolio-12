# JPromise
JPromise is a Java package providing a set of classes which can be used
introduce the [Promise pattern](https://en.wikipedia.org/wiki/Futures_and_promises)
into your Java projects. As a result, it will be easier to create and handle
asynchronous code.


The syntax used by JPromise is based on the JavaScript syntax for Promises, see
the snippets below for simple examples in Java.

### Quick example
In the snippet below you can find a simple interaction between two methods with
the use of a promise. This is what most of your promises will look like.
Creating and returning a promise with one method and adding tasks to perform
when it resolves (or rejects) from another method.

```java
public void myMethod() {
    myPromise().then(() -> System.out.println("Done!"));
}

public SimplePromise myPromise() {
    return new SimplePromise((resolve, reject) -> {
        // do stuff
        resolve.call();
    });
}
```

Two important keywords to understand here are `resolve` and `reject`. When a
promise `resolves`, it means that it successfully did what it had to do. On the
other hand, when a promise `rejects` it means that it failed to do what it
should've done.

* * *

# Using JPromise
There are two things related to promises you should know, [how to create
them](#creating-a-promise) and [how to handle them](#handling-a-promise). The
examples below will help understand how to do both of these.

### Creating a Promise
To create a promise you have to specify the type of promise and optionally the
type(s) the promise resolves or rejects into. The simplest promise to use is the
`SimplePromise`, which does not return anything when it resolves or rejects.
```java
public SimplePromise simplePromiseExample() {
    return new SimplePromise((resolve, reject) -> resolve.call());
}
```

In order to return something with a promise you can for example use the
`UnaryPromise`.
```java
public UnaryPromise<String> unaryPromiseExample() {
    return new UnaryPromise<>((resolve, reject) -> resolve.call("Hello world!"));
}
```

Sometimes, however, you don't really want to return a promise but the return
type is a promise anyway (e.g. when you're implementing an interface). for these
cases most promise implementations offer the methods `.resolve()` and
`.reject()`. These return a promise that is resolved or rejected instantly,
which in turn automatically performs all the tasks set for the promise.
```java
public UnaryPromise<String> staticResolveExample() {
    return UnaryPromise.resolve("Hello world!");
}

public UnaryPromise<String> staticRejectExample() {
    return UnaryPromise.reject("Goodbye cruel world!");
}
```

Another nice feature offered by most promise implementations is the `.all()`
method. This method can be used to wait for a collection of promises before
running any tasks. A promise created by `.all()` resolves only after all the
promises in the provided collection resolved, but rejects as soon as only one
promise rejects.
```java
public SimplePromise waitForAllPromises() {
    List<SimplePromise> promises = new ArrayList<>();
    promises.add(/* add promises to the list */);

    return SimplePromise.all(promises);
}
```

### Handling a Promise
To handle either a resolution or rejection, JPromise provides the methods
`.then()` and `.except()`, which can be used to add tasks to perform when a
promise resolves or rejects respectively.
```java
public void handlePromise() {
    SimplePromise promise = methodThatReturnsAPromise();
    promise.then(() -> {
        // Do something on success
    });
    promise.except(() -> {
        // Do something on failure
    });
}
```

However, this code looks a little bit ugly. Luckily JPromise allows you to chain
`.then()`s and `.except()`s together.
```java
public void handlePromiseNice() {
    methodThatReturnsAPromise()
        .then(() -> {
            // Do something on success
        })
        .except(() -> {
            // Do something on failure
        });
}
```

But you're not limited to one `.then()` and one `.except()`, in fact, you can
add as many as you like. The nice thing about this is that the tasks will always
be performed in the order in which they're added.
```java
public void handlePromise() {
    methodThatReturnsAPromise()
        .then(() -> /* does something first */)
        .then(() -> /* does something else after that */);
}
```
