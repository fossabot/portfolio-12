package promise;

import consumer.BinaryConsumer;
import consumer.SimpleConsumer;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * The {@link SimplePromise} class provides a way of dealing with asynchronous
 * code in Java with the help of {@link consumer.SimpleConsumer
 * SimpleConsumers}. As a result, a {@link SimplePromise} cannot propagate any
 * arguments to the tasks ran when it is being resolved or rejected.
 * <br><br>
 * Should be used as follows:
 * <br>
 * {@code
 *  public SimplePromise foobar() {
 *      return new SimplePromise<>((resolve, reject) -> { ... });
 *  }
 * }
 * <br><br>
 * However, in some cases you might want to use the static methods {@link
 * #resolve resolve()} or {@link #reject reject()} to return a fake {@link
 * SimplePromise}. This should be used as follows:
 * <br>
 * {@code
 *  public SimplePromise foobar() {
 *      return SimplePromise.resolve();
 *  }
 * }
 * <br><br>
 * A useful tool offered by the {@link SimplePromise} is the {@link #all all()}
 * method. This can be used to wait for multiple Promises and perform an action
 * when they're all done.
 */
public final class SimplePromise extends AbstractPromise<SimpleConsumer> {

    /**
     * A null-object of the type {@link SimpleConsumer} used by {@link #all
     * all()}.
     */
    private static final SimpleConsumer NULL_CONSUMER = () -> {};

    /**
     * Create a new {@link SimplePromise}. A {@link SimplePromise} expects a
     * {@code Lambda} which accepts two {@link consumer.SimpleConsumer
     * SimpleConsumers}. These are used to either resolve or reject the Promise.
     * The first {@link consumer.SimpleConsumer} can be used to resolve the
     * Promise via {@code call()}. The second {@link consumer.SimpleConsumer}
     * can be used to reject the Promise via {@code call()}.
     * <br><br>
     * {@code return new SimplePromise<>((resolve, reject) -> { ... });}
     * <br><br>
     * A {@link SimplePromise} opens a new {@link Thread} for the code it has to
     * run. This {@link Thread} closes automatically when the Promise is being
     * resolved or rejected.
     *
     * @param   consumer    A {@code Lambda} that takes two arguments, one to
     *                      resolve the {@link SimplePromise} and one to reject
     *                      the {@link SimplePromise}.
     */
    public SimplePromise(final BinaryConsumer<SimpleConsumer, SimpleConsumer> consumer) {
        final AdvancedSimpleConsumer resolve = super::_resolve;
        final AdvancedSimpleConsumer reject = super::_reject;

        final Thread thread = new Thread() {
            public void run() {
                try {
                    // Add a pre run task that interrupts this Thread to both
                    // the resolve and reject Consumer.
                    SimpleConsumer interrupt = () -> this.interrupt();
                    AdvancedSimpleConsumer.addPreRunTask(resolve, reject, interrupt);

                    // Call the consumer given to the Promise.
                    consumer.call(resolve, reject);

                    // Sleep for a long time.
                    Thread.sleep(Integer.MAX_VALUE);
                } catch(InterruptedException e) { /* Ends the Thread. */ }
            }
        };

        thread.start();
    }

    /**
     * Create a new {@link SimplePromise} that resolves when all the {@link
     * SimplePromise SimplePromises} in the provided {@link Collection} have
     * resolved.
     * <br><br>
     * The {@link SimplePromise} created by this method resolves only when each
     * element in {@code promises} resolved. However, as soon as a single
     * element rejects the {@link SimplePromise} will reject (instantly) as
     * well.
     *
     * @param   promises    The {@code SimplePromise SimplePromises} the new
     *                      {@link SimplePromise} waits for until resolving.
     * @return              A new {@link SimplePromise}.
     */
    public static SimplePromise all(final Collection<SimplePromise> promises) {
        // Create a queue of N - 1 elements, where N is the amount of Promises,
        // filled with null Consumers.
        final int max = promises.size();
        final Queue<SimpleConsumer> consumers = new LinkedList<>();
        for(int i = 0; i < max - 1; i++) {
            consumers.add(SimplePromise.NULL_CONSUMER);
        }

        return new SimplePromise((resolve, reject) -> {
            // Add resolve as the last Consumer in the Queue.
            consumers.add(resolve);

            // Add an (additional) then and except task to each Promise.
            for(SimplePromise promise : promises) {
                promise.except(reject) // Reject as soon as one Promise rejects.
                    .then(() -> {
                        // Get & Removed the first Consumer in the queue and run
                        // it. Since 'resolve' is the last Consumer in the Queue
                        // it will only be called after every Promise resolved.
                        SimpleConsumer consumer = consumers.remove();
                        consumer.call();
                    });
            }
        });
    }

    /**
     * Create a {@link SimplePromise} that is resolved by default. As a result
     * it will automatically run all the tasks set via {@link #then then()}.
     *
     * @return              A resolved {@link SimplePromise}.
     */
    public static SimplePromise resolve() {
        return new SimplePromise((resolve, reject) -> resolve.call());
    }

    /**
     * Create a {@link SimplePromise} that is rejected by default. As a result
     * it will automatically run all the tasks set via {@link #except except()}.
     *
     * @return              A rejected {@link SimplePromise}.
     */
    public static SimplePromise reject() {
        return new SimplePromise((resolve, reject) -> reject.call());
    }

    /** {@inheritDoc} */
    @Override
    /* package */ void runTask(final SimpleConsumer task) {
        task.call();
    }

}
