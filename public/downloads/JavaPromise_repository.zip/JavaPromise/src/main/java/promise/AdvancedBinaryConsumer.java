package promise;

import consumer.SimpleConsumer;
import consumer.BinaryConsumer;

import java.util.HashMap;
import java.util.Map;

/**
 * Represents a function that accepts no arguments and produces no result. With
 * the additional functionality that it implements an observer-like pattern
 * where it is possible to add a task ({@link SimpleConsumer}) to run before the
 * {@link AdvancedBinaryConsumer} is ran.
 * <br><br>
 * This is a {@code functional interface} whose functional method is {@link
 * #call call()}.
 */
@FunctionalInterface
/* package */ interface AdvancedBinaryConsumer<T, U> extends BinaryConsumer<T, U> {

    /**
     * A null-object of the type {@link BinaryConsumer} used by {@link #call
     * call()}.
     */
    /* package */ static final BinaryConsumer NULL_CONSUMER = (t, u) -> {};

    /**
     * A mapping from {@link BinaryConsumer BinaryConsumers} to tasks ({@link
     * SimpleConsumer SimpleConsumers}). The {@code values} are performed as
     * soon, and always before, the key is being performed.
     */
    /* package */ static Map<BinaryConsumer, SimpleConsumer> tasks = new HashMap<>();
    /**
     * A mapping from {@link BinaryConsumer BinaryConsumers} to {@link
     * BinaryConsumer BinaryConsumers} that have the same pre run task.
     */
    /* package */ static Map<BinaryConsumer, BinaryConsumer> relations = new HashMap<>();

    /**
     * Perform the operation.
     *
     * @param   t           The first input argument.
     * @param   u           The second input argument.
     */
    /* package */ void execute(final T t, final U u);

    /**
     * Perform the operation and perform the pre run task.
     *
     * @param   t           The first input argument.
     * @param   u           The second input argument.
     */
    /* package */ default void call(final T t, final U u) {
        // Perform the pre run task.
        SimpleConsumer task = AdvancedBinaryConsumer.tasks.getOrDefault(this, AdvancedSimpleConsumer.NULL_CONSUMER);
        task.call();

        // Remove the pre run task.
        AdvancedBinaryConsumer.removePreRunTask(this, task);

        // Perform the operation.
        this.execute(t, u);
    }

    /**
     * Add a task to run before the {@link BinaryConsumer} is {@link #call
     * called}.
     *
     * @param   consumer    The {@code BinaryConsumer} to add the task to.
     * @param   task        The {@code SimpleConsumer} to add as task.
     */
    /* package */ static void addPreRunTask(final BinaryConsumer consumer, final SimpleConsumer task) {
        AdvancedBinaryConsumer.tasks.put(consumer, task);
    }

    /**
     * Add a task to run before either of the provided {@link BinaryConsumer
     * BinaryConsumers} is {@link #call called}. The side-effect of using this
     * method is that the provided task will only be ran once, when either
     * {@code consumerA} or {@code consumerB} is being {@link #call called}.
     *
     * @param   consumerA   The first {@code BinaryConsumer} to add the task to.
     * @param   consumerB   The second {@code BinaryConsumer} to add the task to.
     * @param   task        The {@code SimpleConsumer} to add as task.
     */
    /* package */ static void addPreRunTask(final BinaryConsumer consumerA, final BinaryConsumer consumerB, final SimpleConsumer task) {
        // Add task as pre runt ask to both Consumers.
        AdvancedBinaryConsumer.addPreRunTask(consumerA, task);
        AdvancedBinaryConsumer.addPreRunTask(consumerB, task);

        // Create a relations between the two Consumers and the task.
        AdvancedBinaryConsumer.relations.put(consumerA, consumerB);
        AdvancedBinaryConsumer.relations.put(consumerB, consumerA);
    }

    /**
     * Remove a task to run before the {@link BinaryConsumer} is {@link #call
     * called}. When the {@code consumer} is related to another {@link
     * BinaryConsumer}, the task will also be removed there.
     *
     * @param   consumer    The {@code BinaryConsumer} to remove te task from.
     * @param   task        The {@code SimpleConsumer} to remove.
     */
    /* package */ static void removePreRunTask(final BinaryConsumer consumer, final SimpleConsumer task) {
        BinaryConsumer that = AdvancedBinaryConsumer.relations.getOrDefault(consumer, AdvancedBinaryConsumer.NULL_CONSUMER);

        AdvancedBinaryConsumer.tasks.remove(consumer, task);
        AdvancedBinaryConsumer.relations.remove(consumer, that);

        AdvancedBinaryConsumer.tasks.remove(that, task);
        AdvancedBinaryConsumer.relations.remove(that, consumer);
    }

}
