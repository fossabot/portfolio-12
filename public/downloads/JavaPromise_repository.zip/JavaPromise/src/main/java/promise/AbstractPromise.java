package promise;

import java.util.ArrayList;
import java.util.List;

/**
 * The {@link AbstractPromise} class is the standard implementation of a {@code
 * Promise} for the JavaPromise package.
 * <br><br>
 * The generic type of this abstract class defines the type of {@code Consumer}
 * the final implementation of the {@code Promise} wants to use.
 */
/* package */ abstract class AbstractPromise<C> implements Promise<C> {

    /**
     * A boolean indicating whether or not the {@code Promise} has been
     * complied to . I.e., has the {@code Promise} either been resolved or
     * rejected.
     */
    private boolean complied = false;
    /**
     * A boolean indicating whether or not the {@code Promise} has been
     * resolved.
     */
    private boolean resolved = false;
    /**
     * A boolean indicating whether or not the {@code Promise} has been
     * rejected.
     */
    private boolean rejected = false;
    /**
     * The tasks to run when the {@code Promise} is being resolved.
     */
    private List<C> resolves = new ArrayList<>();
    /**
     * The tasks to run when the {@code Promise} is being rejected.
     */
    private List<C> rejects = new ArrayList<>();

    /**
     * {@inheritDoc}
     * <br><br>
     * The tasks will always be run in the order in which they're added.
     */
    @Override
    public final synchronized Promise<C> then(final C task) {
        if(this.isComplied() && this.isResolved()) {
            this.runTask(task);
        } else {
            this.resolves.add(task);
        }

        // Return this Promise to allow chaining of 'then's and 'except's.
        return this;
    }

    /**
     * {@inheritDoc}
     * <br><br>
     * The tasks will always be run in the order in which they're added.
     */
    @Override
    public final synchronized Promise<C> except(final C task) {
        if(this.isComplied() && this.isRejected()) {
            this.runTask(task);
        } else {
            this.rejects.add(task);
        }

        // Return this Promise to allow chaining of 'then's and 'except's.
        return this;
    }

    /**
     * Resolve the {@code Promise}. This will run all the tasks set via {@link
     * #then then()}.
     * <br><br>
     * After the {@code Promise} has been resolved it can't be resolved again,
     * nor can it be rejected.
     */
    /* package */ synchronized void _resolve() {
        if(!this.isComplied()) {
            this.comply();
            this.resolved = true;
            this.resolves.forEach(this::runTask);
        }
    }

    /**
     * Reject the {@code Promise}. This will run all the tasks set via {@link
     * #except except()}.
     * <br><br>
     * After the {@code Promise} has been rejected it can't be rejected again,
     * nor can it be resolved.
     */
    /* package */ synchronized void _reject() {
        if(!this.isComplied()) {
            this.comply();
            this.rejected = true;
            this.rejects.forEach(this::runTask);
        }
    }

    /**
     * Run a task of the {@code Promise}.
     *
     * @param   task        The task to run.
     */
    /* package */ abstract void runTask(final C task);

    /**
     * Comply to the {@code Promise}. Note that once a {@code Promise} has been
     * complied to, it is not possible to comply to it again.
     */
    private synchronized void comply() {
        this.complied = true;
    }

    /**
     * Find out whether or not the {@code Promise} has been complied to or not.
     */
    private boolean isComplied() {
        return this.complied;
    }

    /**
     * Find out whether or not the {@code Promise} has been resolved or not.
     */
    private boolean isResolved() {
        return this.resolved;
    }

    /**
     * Find out whether or not the {@code Promise} has been rejected or not.
     */
    private boolean isRejected() {
        return this.rejected;
    }

}
