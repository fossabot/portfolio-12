package promise;

import consumer.BinaryConsumer;
import consumer.SimpleConsumer;
import consumer.UnaryConsumer;
import util.Pair;
import util.ImmutableValue;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;
import java.util.Queue;

/**
 * The {@link BinaryPromise} class provides a way of dealing with asynchronous
 * code in Java with the help of {@link consumer.BinaryConsumer
 * BinaryConsumers}. As a result, a {@link BinaryPromise} can propagate two
 * arguments to the tasks ran when it is being resolved or rejected.
 * <br><br>
 * Normally, a {@link BinaryPromise} will be used as follows:
 * <br>
 * {@code
 *  public BinaryPromise foobar() {
 *      return new BinaryPromise<>((resolve, reject) -> { ... });
 *  }
 * }
 * <br><br>
 * However, in some cases you might want to use the static methods {@link
 * #resolve resolve()} or {@link #reject reject()} to return a fake {@link
 * BinaryPromise}. This should be used as follows:
 * <br>
 * {@code
 *  public BinaryPromise foobar() {
 *      return BinaryPromise.resolve("foo", "bar");
 *  }
 * }
 * <br><br>
 * A useful tool offered by the {@link BinaryPromise} is the {@link #all all()}
 * method. This can be used to wait for multiple Promises and perform an action
 * when they're all done.
 */

public final class BinaryPromise<T, U> extends AbstractPromise<BinaryConsumer<T, U>> {

    /**
     * A null-object of the type {@link UnaryConsumer} used by {@link #all
     * all()}.
     */
    private static final UnaryConsumer NULL_CONSUMER = (argument) -> {};

    /**
     * An {@link util.ImmutableValue ImmutableValue} for the first argument to
     * be passed on to each task when the {@link BinaryPromise} resolves or
     * rejects.
     */
    private ImmutableValue<T> argOne = new ImmutableValue<>();
    /**
     * An {@link util.ImmutableValue ImmutableValue} for the second argument to
     * be passed on to each task when the {@link BinaryPromise} resolves or
     * rejects.
     */
    private ImmutableValue<U> argTwo = new ImmutableValue<>();

    /**
     * Create a new {@link BinaryPromise}. A {@link BinaryPromise} expects a
     * {@code Lambda} which accepts two {@link consumer.BinaryConsumer
     * BinaryConsumers}. These are used to either resolve or reject the {@code
     * Promise}. The first {@link consumer.BinaryConsumer} can be used to
     * resolve the {@code Promise} via {@code .call()}. The second {@link
     * consumer.BinaryConsumer} can be used to reject the {@code Promise} via
     * {@code .call()}.
     * <br><br>
     * {@code return new BinaryPromise<>((resolve, reject) -> { ... });}
     * <br><br>
     * A {@link BinaryPromise} opens a new {@link Thread} for the code it has to
     * run. This {@link Thread} closes automatically when the Promise is being
     * resolved or rejected.
     *
     * @param   consumer    A {@code Lambda} that takes two arguments, one to
     *                      resolve the {@link BinaryPromise} and one to reject
     *                      the {@link BinaryPromise}.
     */
    public BinaryPromise(final BinaryConsumer<BinaryConsumer<T, U>, BinaryConsumer<T, U>> consumer) {
        final AdvancedBinaryConsumer<T, U> resolve = this::_resolve;
        final AdvancedBinaryConsumer<T, U> reject = this::_reject;

        final Thread thread = new Thread() {
            public void run() {
                try {
                    // Add a pre run task that interrupts this Thread to both
                    // the resolve and reject Consumer.
                    SimpleConsumer interrupt = () -> this.interrupt();
                    AdvancedBinaryConsumer.addPreRunTask(resolve, reject, interrupt);

                    // Call the consumer given to the Promise.
                    consumer.call(resolve, reject);

                    // Sleep for a long time.
                    Thread.sleep(Integer.MAX_VALUE);
                } catch(InterruptedException e) { /* Ends the Thread. */ }
            }
        };

        thread.start();
    }

    /**
     * Create a new {@link UnaryPromise} that resolves when all the {@link
     * BinaryPromise BinaryPromises} in the provided {@link Collection} have
     * resolved. Note that {@link #all BinaryPromise.all()} returns a {@link
     * UnaryPromise} instead of a {@link BinaryPromise}.
     * <br><br>
     * The {@link UnaryPromise} created by this method resolves only when each
     * element in {@code promises} resolved. However, as soon as a single
     * element rejects the {@link UnaryPromise} will reject (instantly) as
     * well.
     * <br><br>
     * When this {@link UnaryPromise} resolves, the argument passed to {@link
     * #then then()} is a {@link Set} containing a {@link Pair} for each result
     * of the Promises provided to this method. When it rejects however, the
     * passed to {@link #except except()} will be a {@link Set} with only one
     * {@link Pair} which contains the arguments it received from the first
     * Promise that rejected.
     *
     * @param   <K>         The type of the first arguments of the Promises in
     *                      the provided {@link Collection} of {@link
     *                      BinaryPromise BinaryPromises}.
     * @param   <L>         The type of the second arguments of the Promises in
     *                      the provided {@link Collection} of {@link
     *                      BinaryPromise BinaryPromises}.
     * @param   promises    The {@code BinaryPromise BinaryPromises} the new
     *                      {@link UnaryPromise} waits for until resolving.
     * @return              A new {@link UnaryPromise}.
     */
    @SuppressWarnings("unchecked") // Needed for NULL_CONSUMER
    public static <K, L> UnaryPromise<Set<Pair<K, L>>> all(final Collection<BinaryPromise<K, L>> promises) {
        // Create two Sets of Pairs arguments which are gathered from the
        // resolves/rejects of the list of Promises and passed on to the resolve
        // /reject of the new Promise.
        final Set<Pair<K, L>> resolveArgs = new HashSet<>();
        final Set<Pair<K, L>> rejectArgs = new HashSet<>();

        // Create a queue of N - 1 elements, where N is the amount of Promises,
        // filled with null Consumers.
        final int max = promises.size();
        final Queue<UnaryConsumer<Set<Pair<K, L>>>> consumers = new LinkedList<>();
        for(int i = 0; i < max - 1; i++) {
            consumers.add(BinaryPromise.NULL_CONSUMER);
        }

        final UnaryPromise<Set<Pair<K, L>>> p = new UnaryPromise<>((resolve, reject) -> {
            // Add resolve as the last Consumer in the Queue.
            consumers.add(resolve);

            // Add an (additional) then and except task to each Promise.
            for(BinaryPromise<K, L> promise : promises) {
                promise
                    .except((argOne, argTwo) -> {
                        // Reject as soon as one Promise rejects.
                        if(rejectArgs.size() == 0) {
                            Pair<K, L> pair = new Pair<>(argOne, argTwo);
                            rejectArgs.add(pair);
                            reject.call(rejectArgs);
                        }
                    })
                    .then((argOne, argTwo) -> {
                        // Each argument from a resolved Promise should be
                        // passed on to the resolve argument of this Promise.
                        Pair<K, L> pair = new Pair<>(argOne, argTwo);
                        resolveArgs.add(pair);

                        // Get & Removed the first Consumer in the queue and run
                        // it. Since 'resolve' is the last Consumer in the Queue
                        // it will only be called when every Promise resolves.
                        UnaryConsumer<Set<Pair<K, L>>> consumer = consumers.remove();
                        consumer.call(resolveArgs);
                    });
            }
        });

        return p;
    }

    /**
     * Create a {@link BinaryPromise} that is resolved by default. As a result
     * it will automatically run all the tasks set via {@link #then then()}.
     *
     * @param   <K>         The type of the first argument for the {@link
     *                      BinaryPromise}.
     * @param   <L>         The type of the second argument for the {@link
     *                      BinaryPromise}.
     * @param   argOne      The first argument to pass to the resolve task(s).
     * @param   argTwo      The second argument to pass to the resolve task(s).
     * @return              A resolved {@link UnaryPromise}.
     */
    public static <K, L> BinaryPromise<K, L> resolve(final K argOne, final L argTwo) {
        return new BinaryPromise<K, L>((resolve, reject) -> {
            resolve.call(argOne, argTwo);
        });
    }

    /**
     * Create a {@link BinaryPromise} that is rejected by default. As a result
     * it will automatically run all the tasks set via {@link #except except()}.
     *
     * @param   <K>         The type of the first argument for the {@link
     *                      BinaryPromise}.
     * @param   <L>         The type of the second argument for the {@link
     *                      BinaryPromise}.
     * @param   argOne      The first argument to pass to the reject task(s).
     * @param   argTwo      The second argument to pass to the reject task(s).
     * @return              A rejected {@link UnaryPromise}.
     */
    public static <K, L> BinaryPromise<K, L> reject(final K argOne, final L argTwo) {
        return new BinaryPromise<K, L>((resolve, reject) -> {
            reject.call(argOne, argTwo);
        });
    }

    /**
     * Resolve the {@link BinaryPromise} via the {@link AbstractPromise}.
     *
     * @param   argOne      The first argument to pass to the resolve task(s).
     * @param   argTwo      The second argument to pass to the resolve task(s).
     */
    /* package */ synchronized void _resolve(final T argOne, final U argTwo) {
        this.argOne.setValue(argOne);
        this.argTwo.setValue(argTwo);
        super._resolve();
    }

    /**
     * Reject the {@link BinaryPromise} via the {@link AbstractPromise}.
     *
     * @param   argOne      The first argument to pass to the reject task(s).
     * @param   argTwo      The second argument to pass to the reject task(s).
     */
    /* package */ synchronized void _reject(final T argOne, final U argTwo) {
        this.argOne.setValue(argOne);
        this.argTwo.setValue(argTwo);
        super._reject();
    }

    /** {@inheritDoc} */
    @Override
    /* package */ void runTask(final BinaryConsumer<T, U> task) {
        task.call(this.argOne.getValue(), this.argTwo.getValue());
    }

}
