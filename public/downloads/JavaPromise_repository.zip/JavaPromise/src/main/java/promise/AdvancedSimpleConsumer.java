package promise;

import consumer.SimpleConsumer;

import java.util.HashMap;
import java.util.Map;

/**
 * Represents a function that accepts no arguments and produces no result. With
 * the additional functionality that it implements an observer-like pattern
 * where it is possible to add a task ({@link SimpleConsumer}) to run before the
 * {@link AdvancedSimpleConsumer} is ran.
 * <br><br>
 * This is a {@code functional interface} whose functional method is {@link
 * #call call()}.
 */
@FunctionalInterface
/* package */ interface AdvancedSimpleConsumer extends SimpleConsumer {

    /**
     * A null-object of the type {@link SimpleConsumer} used by {@link #call
     * call()}.
     */
    /* package */ static final SimpleConsumer NULL_CONSUMER = () -> {};

    /**
     * A mapping from {@link SimpleConsumer SimpleConsumers} to tasks (also
     * {@link SimpleConsumer SimpleConsumers}). The {@code values} are performed
     * as soon, and always before, the key is being performed.
     */
    /* package */ static Map<SimpleConsumer, SimpleConsumer> tasks = new HashMap<>();
    /**
     * A mapping from {@link SimpleConsumer SimpleConsumers} to {@link
     * SimpleConsumer SimpleConsumers} that have the same pre run task.
     */
    /* package */ static Map<SimpleConsumer, SimpleConsumer> relations = new HashMap<>();

    /**
     * Perform the operation.
     */
    /* package */ void execute();

    /**
     * Perform the operation and perform the pre run task.
     */
    /* package */ default void call() {
        // Perform the pre run task.
        SimpleConsumer task = AdvancedSimpleConsumer.tasks.getOrDefault(this, AdvancedSimpleConsumer.NULL_CONSUMER);
        task.call();

        // Remove the pre run task.
        AdvancedSimpleConsumer.removePreRunTask(this, task);

        // Perform the operation.
        this.execute();
    }

    /**
     * Add a task to run before the {@link SimpleConsumer} is {@link #call
     * called}.
     *
     * @param   consumer    The {@code SimpleConsumer} to add the task to.
     * @param   task        The {@code SimpleConsumer} to add as task.
     */
    /* package */ static void addPreRunTask(final SimpleConsumer consumer, final SimpleConsumer task) {
        AdvancedSimpleConsumer.tasks.put(consumer, task);
    }

    /**
     * Add a task to run before either of the provided {@link SimpleConsumer
     * SimpleConsumers} is {@link #call called}. The side-effect of using this
     * method is that the provided task will only be ran once, when either
     * {@code consumerA} or {@code consumerB} is being {@link #call called}.
     *
     * @param   consumerA   The first {@code SimpleConsumer} to add the task to.
     * @param   consumerB   The second {@code SimpleConsumer} to add the task to.
     * @param   task        The {@code SimpleConsumer} to add as task.
     */
    /* package */ static void addPreRunTask(final SimpleConsumer consumerA, final SimpleConsumer consumerB, final SimpleConsumer task) {
        // Add task as pre runt ask to both Consumers.
        AdvancedSimpleConsumer.addPreRunTask(consumerA, task);
        AdvancedSimpleConsumer.addPreRunTask(consumerB, task);

        // Create a relations between the two Consumers and the task.
        AdvancedSimpleConsumer.relations.put(consumerA, consumerB);
        AdvancedSimpleConsumer.relations.put(consumerB, consumerA);
    }

    /**
     * Remove a task to run before the {@link SimpleConsumer} is {@link #call
     * called}. When the {@code consumer} is related to another {@link
     * SimpleConsumer}, the task will also be removed there.
     *
     * @param   consumer    The {@code SimpleConsumer} to remove te task from.
     * @param   task        The {@code SimpleConsumer} to remove.
     */
    /* package */ static void removePreRunTask(final SimpleConsumer consumer, final SimpleConsumer task) {
        SimpleConsumer that = AdvancedSimpleConsumer.relations.getOrDefault(consumer, AdvancedSimpleConsumer.NULL_CONSUMER);

        AdvancedSimpleConsumer.tasks.remove(consumer, task);
        AdvancedSimpleConsumer.relations.remove(consumer, that);

        AdvancedSimpleConsumer.tasks.remove(that, task);
        AdvancedSimpleConsumer.relations.remove(that, consumer);
    }

}
