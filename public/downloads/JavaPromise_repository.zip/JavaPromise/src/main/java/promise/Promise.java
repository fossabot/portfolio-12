package promise;

/**
 * The {@link Promise} interface provides a way of dealing with asynchronous
 * code in Java with the help of {@code Lambdas}. They allows you to perform
 * simple actions after a method that can take a while to run has finished,
 * without freezing your application.
 * <br><br>
 * JavaPromise's way of using Promises is inspired by JavaScript. Generally
 * speaking, a Promise should be used as follows:
 * <br>
 * {@code return new Promise((resolve, reject) -> { ... });}
 */
public interface Promise<C> {

    /**
     * Add a task to run when the {@code Promise} resolves. The {@code Promise}
     * returned by this method is the same as the one that called it. This
     * allows you to chain multiple {@link #then then()}s and {@link #except
     * except()}s together.
     *
     * @param   task        The {@code Callable} to run upon resolving.
     * @return              The {@code Promise} that called the method.
     */
    public Promise<C> then(final C task);

    /**
     * Add a task to run when the {@code Promise} rejects. The {@code Promise}
     * returned by this method is the same as the one that called it. This
     * allows you to chain multiple {@link #then then()}s and {@link #except
     * except()}s together.
     *
     * @param   task        The {@code Callable} to run upon rejecting.
     * @return              The {@code Promise} that called the method.
     */
    public Promise<C> except(final C task);

}
