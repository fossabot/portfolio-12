package promise;

import consumer.SimpleConsumer;
import consumer.UnaryConsumer;

import java.util.HashMap;
import java.util.Map;

/**
 * Represents a function that accepts no arguments and produces no result. With
 * the additional functionality that it implements an observer-like pattern
 * where it is possible to add a task ({@link SimpleConsumer}) to run before the
 * {@link AdvancedUnaryConsumer} is ran.
 * <br><br>
 * This is a {@code functional interface} whose functional method is {@link
 * #call call()}.
 */
@FunctionalInterface
/* package */ interface AdvancedUnaryConsumer<T> extends UnaryConsumer<T> {

    /**
     * A null-object of the type {@link UnaryConsumer} used by {@link #call
     * call()}.
     */
    /* package */ static final UnaryConsumer NULL_CONSUMER = (t) -> {};

    /**
     * A mapping from {@link UnaryConsumer UnaryConsumers} to tasks ({@link
     * SimpleConsumer SimpleConsumers}). The {@code values} are performed as
     * soon, and always before, the key is being performed.
     */
    /* package */ static Map<UnaryConsumer, SimpleConsumer> tasks = new HashMap<>();
    /**
     * A mapping from {@link UnaryConsumer UnaryConsumers} to {@link
     * UnaryConsumer UnaryConsumers} that have the same pre run task.
     */
    /* package */ static Map<UnaryConsumer, UnaryConsumer> relations = new HashMap<>();

    /**
     * Perform the operation.
     *
     * @param   t           The first input argument.
     */
    /* package */ void execute(final T t);

    /**
     * Perform the operation and perform the pre run task.
     *
     * @param   t           The first input argument.
     */
    /* package */ default void call(final T t) {
        // Perform the pre run task.
        SimpleConsumer task = AdvancedUnaryConsumer.tasks.getOrDefault(this, AdvancedSimpleConsumer.NULL_CONSUMER);
        task.call();

        // Remove the pre run task.
        AdvancedUnaryConsumer.removePreRunTask(this, task);

        // Perform the operation.
        this.execute(t);
    }

    /**
     * Add a task to run before the {@link UnaryConsumer} is {@link #call
     * called}.
     *
     * @param   consumer    The {@code UnaryConsumer} to add the task to.
     * @param   task        The {@code SimpleConsumer} to add as task.
     */
    /* package */ static void addPreRunTask(final UnaryConsumer consumer, final SimpleConsumer task) {
        AdvancedUnaryConsumer.tasks.put(consumer, task);
    }

    /**
     * Add a task to run before either of the provided {@link UnaryConsumer
     * UnaryConsumers} is {@link #call called}. The side-effect of using this
     * method is that the provided task will only be ran once, when either
     * {@code consumerA} or {@code consumerB} is being {@link #call called}.
     *
     * @param   consumerA   The first {@code UnaryConsumer} to add the task to.
     * @param   consumerB   The second {@code UnaryConsumer} to add the task to.
     * @param   task        The {@code SimpleConsumer} to add as task.
     */
    /* package */ static void addPreRunTask(final UnaryConsumer consumerA, final UnaryConsumer consumerB, final SimpleConsumer task) {
        // Add task as pre runt ask to both Consumers.
        AdvancedUnaryConsumer.addPreRunTask(consumerA, task);
        AdvancedUnaryConsumer.addPreRunTask(consumerB, task);

        // Create a relations between the two Consumers and the task.
        AdvancedUnaryConsumer.relations.put(consumerA, consumerB);
        AdvancedUnaryConsumer.relations.put(consumerB, consumerA);
    }

    /**
     * Remove a task to run before the {@link UnaryConsumer} is {@link #call
     * called}. When the {@code consumer} is related to another {@link
     * UnaryConsumer}, the task will also be removed there.
     *
     * @param   consumer    The {@code UnaryConsumer} to remove te task from.
     * @param   task        The {@code SimpleConsumer} to remove.
     */
    /* package */ static void removePreRunTask(final UnaryConsumer consumer, final SimpleConsumer task) {
        UnaryConsumer that = AdvancedUnaryConsumer.relations.getOrDefault(consumer, AdvancedUnaryConsumer.NULL_CONSUMER);

        AdvancedUnaryConsumer.tasks.remove(consumer, task);
        AdvancedUnaryConsumer.relations.remove(consumer, that);

        AdvancedUnaryConsumer.tasks.remove(that, task);
        AdvancedUnaryConsumer.relations.remove(that, consumer);
    }

}
