package promise;

import consumer.BinaryConsumer;
import consumer.SimpleConsumer;
import consumer.UnaryConsumer;
import util.ImmutableValue;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;
import java.util.Queue;

/**
 * The {@link UnaryPromise} class provides a way of dealing with asynchronous
 * code in Java with the help of {@link consumer.UnaryConsumer UnaryConsumers}.
 * As a result, a {@link UnaryPromise} can propagate one argument to the tasks
 * ran when it is being resolved or rejected.
 * <br><br>
 * Should be used as follows:
 * <br>
 * {@code
 *  public UnaryPromise foobar() {
 *      return new UnaryPromise<>((resolve, reject) -> { ... });
 *  }
 * }
 * <br><br>
 * However, in some cases you might want to use the static methods {@link
 * #resolve resolve()} or {@link #reject reject()} to return a fake {@link
 * UnaryPromise}. This should be used as follows:
 * <br>
 * {@code
 *  public UnaryPromise foobar() {
 *      return UnaryPromise.resolve("foobar");
 *  }
 * }
 * <br><br>
 * A useful tool offered by the {@link UnaryPromise} is the {@link #all all()}
 * method. This can be used to wait for multiple Promises and perform an action
 * when they're all done.
 */
public final class UnaryPromise<T> extends AbstractPromise<UnaryConsumer<T>> {

    /**
     * A null-object of the type {@link UnaryConsumer} used by {@link #all
     * all()}.
     */
    private static final UnaryConsumer NULL_CONSUMER = (argument) -> {};

    /**
     * An {@link util.ImmutableValue ImmutableValue} for the argument to be
     * passed on to each task when the {@link UnaryPromise} resolves or rejects.
     */
    private ImmutableValue<T> argument = new ImmutableValue<>();

    /**
     * Create a new {@link UnaryPromise}. A {@link UnaryPromise} expects a
     * {@code Lambda} which accepts two {@link consumer.UnaryConsumer
     * UnaryConsumers}. These are used to either resolve or reject the {@code
     * Promise}. The first {@link consumer.UnaryConsumer} can be used to resolve
     * the {@code Promise} via {@code .call()}. The second {@link
     * consumer.UnaryConsumer} can be used to reject the {@code Promise} via
     * {@code .call()}.
     * <br><br>
     * {@code return new UnaryPromise<>((resolve, reject) -> { ... });}
     * <br><br>
     * A {@link UnaryPromise} opens a new {@link Thread} for the code it has to
     * run. This {@link Thread} closes automatically when the Promise is being
     * resolved or rejected.
     *
     * @param   consumer    A {@code Lambda} that takes two arguments, one to
     *                      resolve the {@link UnaryPromise} and one to reject
     *                      the {@link UnaryPromise}.
     */
    public UnaryPromise(final BinaryConsumer<UnaryConsumer<T>, UnaryConsumer<T>> consumer) {
        final AdvancedUnaryConsumer<T> resolve = this::_resolve;
        final AdvancedUnaryConsumer<T> reject = this::_reject;

        final Thread thread = new Thread() {
            public void run() {
                try {
                    // Add a pre run task that interrupts this Thread to both
                    // the resolve and reject Consumer.
                    SimpleConsumer interrupt = () -> this.interrupt();
                    AdvancedUnaryConsumer.addPreRunTask(resolve, reject, interrupt);

                    // Call the consumer given to the Promise.
                    consumer.call(resolve, reject);

                    // Sleep for a long time.
                    Thread.sleep(Integer.MAX_VALUE);
                } catch(InterruptedException e) { /* Ends the Thread. */ }
            }
        };

        thread.start();
    }

    /**
     * Create a new {@link UnaryPromise} that resolves when all the {@link
     * UnaryPromise UnaryPromises} in the provided {@link Collection} have
     * resolved.
     * <br><br>
     * The {@link UnaryPromise} created by this method resolves only when each
     * element in {@code promises} resolved. However, as soon as a single
     * element rejects the {@link UnaryPromise} will reject (instantly) as
     * well.
     * <br><br>
     * When this {@link UnaryPromise} resolves, the argument pass to {@link
     * #then then()} is a {@link Set} containing the result of each of the
     * Promises provided to this method. When it rejects however, the argument
     * passed to {@link #except except()} will be a {@link Set} with only one
     * element, which is the argument it received from the first Promise that
     * rejected.
     *
     * @param   <K>         The type of the arguments of the Promises in the
     *                      provided {@link Collection} of {@link UnaryPromise
     *                      UnaryPromises}.
     * @param   promises    The {@code UnaryPromise UnaryPromises} the new
     *                      {@link UnaryPromise} waits for until resolving.
     * @return              A new {@link UnaryPromise}.
     */
    @SuppressWarnings("unchecked") // Needed for NULL_CONSUMER
    public static <K> UnaryPromise<Set<K>> all(final Collection<UnaryPromise<K>> promises) {
        // Create two Sets for arguments which are gathered from the resolves/
        // rejects of the list of Promises and passed on to the resolve/reject
        // of the new Promise.
        final Set<K> resolveArgs = new HashSet<>();
        final Set<K> rejectArgs = new HashSet<>();

        // Create a queue of N - 1 elements, where N is the amount of Promises,
        // filled with null Consumers.
        final int max = promises.size();
        final Queue<UnaryConsumer<Set<K>>> consumers = new LinkedList<>();
        for(int i = 0; i < max - 1; i++) {
            consumers.add(UnaryPromise.NULL_CONSUMER);
        }

        final UnaryPromise<Set<K>> p = new UnaryPromise<>((resolve, reject) -> {
            // Add resolve as the last Consumer in the Queue.
            consumers.add(resolve);

            // Add an (additional) then and except task to each Promise.
            for(UnaryPromise<K> promise : promises) {
                promise
                    .except((argument) -> {
                        // Reject as soon as one Promise rejects.
                        if(rejectArgs.size() == 0) {
                            rejectArgs.add(argument);
                            reject.call(rejectArgs);
                        }
                    })
                    .then((argument) -> {
                        // Each argument from a resolved Promise should be
                        // passed on to the resolve argument of this Promise.
                        resolveArgs.add(argument);

                        // Get & Removed the first Consumer in the queue and run
                        // it. Since 'resolve' is the last Consumer in the Queue
                        // it will only be called after every Promise resolved.
                        UnaryConsumer<Set<K>> consumer = consumers.remove();
                        consumer.call(resolveArgs);
                    });
            }
        });

        return p;
    }

    /**
     * Create a {@link UnaryPromise} that is resolved by default. As a result
     * it will automatically run all the tasks set via {@link #then then()}.
     *
     * @param   <K>         The argument type for the {@link UnaryPromise}.
     * @param   argument    The argument to pass to the resolve task(s).
     * @return              A resolved {@link UnaryPromise}.
     */
    public static <K> UnaryPromise<K> resolve(final K argument) {
        return new UnaryPromise<K>((resolve, reject) -> {
            resolve.call(argument);
        });
    }

    /**
     * Create a {@link UnaryPromise} that is rejected by default. As a result
     * it will automatically run all the tasks set via {@link #except except()}.
     *
     * @param   <K>         The argument type for the {@link UnaryPromise}.
     * @param   argument    The argument to pass to the reject task(s).
     * @return              A rejected {@link UnaryPromise}.
     */
    public static <K> UnaryPromise<K> reject(final K argument) {
        return new UnaryPromise<K>((resolve, reject) -> {
            reject.call(argument);
        });
    }

    /**
     * Resolve the {@link BinaryPromise} via the {@link AbstractPromise}.
     *
     * @param   argument    The argument to pass to the resolve task(s).
     */
    /* package */ synchronized void _resolve(final T argument) {
        this.argument.setValue(argument);
        super._resolve();
    }

    /**
     * Reject the {@link BinaryPromise} via the {@link AbstractPromise}.
     *
     * @param   argument    The argument to pass to the reject task(s).
     */
    /* package */ synchronized void _reject(final T argument) {
        this.argument.setValue(argument);
        super._reject();
    }

    /** {@inheritDoc} */
    @Override
    /* package */ void runTask(final UnaryConsumer<T> task) {
        task.call(this.argument.getValue());
    }

}
