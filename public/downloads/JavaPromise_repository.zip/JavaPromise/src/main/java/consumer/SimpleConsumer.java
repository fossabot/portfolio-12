package consumer;

/**
 * Represents a function that accepts no arguments and produces no result.
 * <br><br>
 * This is a {@code functional interface} whose functional method is {@link
 * #call call()}.
 */
@FunctionalInterface
public interface SimpleConsumer {

    /**
     * Perform the operation.
     */
    public void call();

}
