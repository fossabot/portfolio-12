package consumer;

/**
 * Represents a function that accepts two arguments and produces no result.
 * This is the two-arity specialization of {@link Consumer}.
 * <br><br>
 * This is a {@link FunctionalInterface functional interface} whose functional
 * method is {@link #call call()}.
 */
@FunctionalInterface
public interface BinaryConsumer<T, U> {

    /**
     * Perform the operation given the arguments.
     *
     * @param   t           The first input argument.
     * @param   u           The second input argument.
     */
    public void call(final T t, final U u);

}
