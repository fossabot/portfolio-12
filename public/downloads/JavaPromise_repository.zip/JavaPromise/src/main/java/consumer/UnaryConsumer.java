package consumer;

/**
 * Represents a function that accepts one argument and produces no result. This
 * is the one-arity specialization of {@link Consumer}.
 * <br><br>
 * This is a {@link FunctionalInterface functional interface} whose functional
 * method is {@link #call call()}.
 */
@FunctionalInterface
public interface UnaryConsumer<T> {

    /**
     * Perform the operation given the argument.
     *
     * @param   t           The input argument.
     */
    public void call(final T t);

}
