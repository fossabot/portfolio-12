package util;

/**
 * A semi-immutable class that can be used to store a single value. It is semi-
 * immutable in that the value cannot be changed, but does not have to be
 * determined on instantiation.
 */
public final class ImmutableValue<T> {

    /**
     * The value of {@link ImmutableValue}.
     */
    private T value;

    /**
     * Create a new {@link ImmutableValue}.
     */
    public ImmutableValue() {
        // Empty constructor should be available.
    }

    /**
     * Create a new {@link ImmutableValue} with a value.
     *
     * @param   value       The value the {@link ImmutableValue} should have.
     */
    public ImmutableValue(final T value) {
        this.value = value;
    }

    /**
     * Get the value of the {@link ImmutableValue}. Note that this may be {@code
     * null} as the constructor is also available without parameter.
     *
     * @return              The value of the {@link ImmutableValue}.
     */
    public T getValue() {
        return this.value;
    }

    /**
     * Set the value of the {@link ImmutableValue} if not set yet. This method
     * only sets the value if the current value is {@code null}. Otherwise
     * nothing changes and <b>no</b> {@code Exception} is thrown.
     *
     * @param   value       The intended value of the {@link ImmutableValue}.
     */
    public void setValue(final T value) {
        if(this.getValue() == null) {
            this.value = value;
        }
    }

    /** {@inheritDoc} */
    @Override
    public boolean equals(final Object o) {
        if(!(o instanceof ImmutableValue)) {
            return false;
        }

        ImmutableValue that = (ImmutableValue) o;

        return this.getValue() != null ?
            this.getValue().equals(that.getValue()) : that.getValue() == null;
    }

}
