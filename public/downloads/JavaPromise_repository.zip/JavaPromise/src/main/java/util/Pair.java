package util;

/**
 * A class representing a pair of values, or in other words: a tuple of two
 * values. The values in a {@link Pair} are <b>Immutable</b> and ordered.
 */
public final class Pair<L, R> {

    /**
     * The left, i.e. first, value of the pair.
     */
    private final L left;
    /**
     * The right, i.e. second, value of the pair.
     */
    private final R right;

    /**
     * Create a new <b>Immutable</b> {@link Pair} with the 2 given values.
     *
     * @param   left        The first value for the pair.
     * @param   right       The second value for the pair.
     */
    public Pair(final L left, final R right) {
        this.left = left;
        this.right = right;
    }

    /**
     * Get the left, that is first, value of the pair.
     *
     * @return              The first value of the pair.
     */
    public L getLeft() {
        return this.left;
    }

    /**
     * Get the right, that is second, value of the pair.
     *
     * @return              The second value of the pair.
     */
    public R getRight() {
        return this.right;
    }

    /** {@inheritDoc} */
    @Override
    public int hashCode() {
        return this.left.hashCode() ^ this.right.hashCode();
    }

    /** {@inheritDoc} */
    @Override
    public boolean equals(final Object o) {
        if(!(o instanceof Pair)) {
            return false;
        }

        Pair that = (Pair) o;

        return (this.getLeft() != null ? this.getLeft().equals(that.getLeft()) : that.getLeft() == null)
            && (this.getRight() != null ? this.getRight().equals(that.getRight()) : that.getRight() == null);
    }

}
