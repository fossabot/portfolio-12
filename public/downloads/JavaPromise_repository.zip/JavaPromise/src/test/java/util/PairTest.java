package util;

import org.junit.Before;
import org.junit.Test;
import org.powermock.reflect.Whitebox;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.powermock.api.mockito.PowerMockito.mock;

public class PairTest {

    private String leftValue = mock(String.class);
    private Integer rightValue = mock(Integer.class);

    private Pair<String, Integer> pair;

    @Before
    public void init() {
        pair = new Pair<>(leftValue, rightValue);
    }

    @Test
    public void testConstructorLeftValue() {
        String actual = Whitebox.getInternalState(pair, "left");
        assertThat(actual, is(leftValue));
    }

    @Test
    public void testConstructorRightValue() {
        Integer actual = Whitebox.getInternalState(pair, "right");
        assertThat(actual, is(rightValue));
    }

    @Test
    public void testLeftGenericType() {
        Object left = Whitebox.getInternalState(pair, "left");
        assertTrue(left instanceof String);
    }

    @Test
    public void testRightGenericType() {
        Object right = Whitebox.getInternalState(pair, "right");
        assertTrue(right instanceof Integer);
    }

    @Test
    public void testGetLeft() {
        String expected = Whitebox.getInternalState(pair, "left");
        String actual = pair.getLeft();
        assertThat(actual, is(expected));
    }

    @Test
    public void testGetRight() {
        Integer expected = Whitebox.getInternalState(pair, "right");
        Integer actual = pair.getRight();
        assertThat(actual, is(expected));
    }

    @Test
    public void testHashCode() {
        pair.hashCode();
        assertTrue(true); // No error
    }

    @Test
    public void testEqualsSameTypeSameValues() {
        boolean actual = pair.equals(new Pair<>(leftValue, rightValue));
        assertTrue(actual);
    }

    @Test
    public void testEqualsSameTypeLeftSameRightDifferent() {
        boolean actual = pair.equals(new Pair<>("foobar", rightValue));
        assertFalse(actual);
    }

    @Test
    public void testEqualsSameTypeLeftDifferentRightSame() {
        boolean actual = pair.equals(new Pair<>(leftValue, 42));
        assertFalse(actual);
    }

    @Test
    public void testEqualsOtherType() {
        boolean actual = pair.equals(leftValue);
        assertFalse(actual);
    }

    @Test
    public void testEqualsLeftNullToNotLeftNull() {
        Pair<String, Integer> leftNull = new Pair<>(null, rightValue);
        boolean actual = leftNull.equals(pair);
        assertFalse(actual);
    }

    @Test
    public void testEqualsLeftNullToLeftNull() {
        Pair<String, Integer> leftNull = new Pair<>(null, rightValue);
        boolean actual = leftNull.equals(leftNull);
        assertTrue(actual);
    }

    @Test
    public void testEqualsRightNullToNotRightNull() {
        Pair<String, Integer> rightNull = new Pair<>(leftValue, null);
        boolean actual = rightNull.equals(pair);
        assertFalse(actual);
    }

    @Test
    public void testEqualsRightNullToRightNull() {
        Pair<String, Integer> rightNull = new Pair<>(leftValue, null);
        boolean actual = rightNull.equals(rightNull);
        assertTrue(actual);
    }

    @Test
    public void testNotBothNulEqualsToBothNull() {
        Pair<String, Integer> bothNull = new Pair<>(null, null);
        boolean actual = pair.equals(bothNull);
        assertFalse(actual);
    }

    @Test
    public void testBothNullEqualsToNotBothNull() {
        Pair<String, Integer> bothNull = new Pair<>(null, null);
        boolean actual = bothNull.equals(pair);
        assertFalse(actual);
    }

}
