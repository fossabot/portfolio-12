package util;

import org.junit.Before;
import org.junit.Test;
import org.powermock.reflect.Whitebox;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.powermock.api.mockito.PowerMockito.mock;

public class ImmutableValueTest {

    private String value = mock(String.class);

    private ImmutableValue<String> emptyValue;
    private ImmutableValue<String> initiatedValue;

    @Before
    public void init() {
        emptyValue = new ImmutableValue<>();
        initiatedValue = new ImmutableValue<>(value);
    }

    @Test
    public void testConstructorWithoutValue() {
        String actual = Whitebox.getInternalState(emptyValue, "value");
        assertNull(actual);
    }

    @Test
    public void testConstructorWithValue() {
        String actual = Whitebox.getInternalState(initiatedValue, "value");
        assertThat(actual, is(value));
    }

    @Test
    public void testGetValueWithoutValue() {
        String expected = Whitebox.getInternalState(emptyValue, "value");
        String actual = emptyValue.getValue();
        assertThat(actual, is(expected));
    }

    @Test
    public void testGetValueWithValue() {
        String expected = Whitebox.getInternalState(initiatedValue, "value");
        String actual = initiatedValue.getValue();
        assertThat(actual, is(expected));
    }

    @Test
    public void testSetValueWithoutValue() {
        String newValue = "foobar";
        emptyValue.setValue(newValue);
        String actual = Whitebox.getInternalState(emptyValue, "value");

        assertThat(actual, is(newValue));
    }

    @Test
    public void testSetValueWithValue() {
        String oldValue = Whitebox.getInternalState(initiatedValue, "value");
        initiatedValue.setValue("foobar");
        String actual = Whitebox.getInternalState(initiatedValue, "value");

        assertThat(actual, is(oldValue));
    }

    @Test
    public void testEqualsSameTypeSameValue() {
        Boolean actual = initiatedValue.equals(new ImmutableValue<>(value));
        assertTrue(actual);
    }

    @Test
    public void testEqualsSameTypeDifferentValue() {
        String otherValue = value + "foobar";
        Boolean actual = initiatedValue.equals(new ImmutableValue<>(otherValue));
        assertFalse(actual);
    }

    @Test
    public void testEqualsOtherType() {
        Boolean actual = initiatedValue.equals(value);
        assertFalse(actual);
    }

    @Test
    public void testEqualsToNull() {
        Boolean actual = initiatedValue.equals(emptyValue);
        assertFalse(actual);
    }

    @Test
    public void testNullEqualsToNotNull() {
        Boolean actual = emptyValue.equals(initiatedValue);
        assertFalse(actual);
    }

    @Test
    public void testNullEqualsToNull() {
        Boolean actual = emptyValue.equals(emptyValue);
        assertTrue(actual);
    }

}
