package promise;

import consumer.UnaryConsumer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.powermock.reflect.Whitebox;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.mock;

@SuppressWarnings("unchecked") // Needed for Consumer mock
public class UnaryPromiseTest {

    private UnaryConsumer consumer = mock(UnaryConsumer.class);

    private UnaryPromise<String> promise;
    private UnaryConsumer resolve;
    private UnaryConsumer reject;

    private UnaryPromise<String> promise2;
    private UnaryConsumer resolve2;
    private UnaryConsumer reject2;

    private String message = "foobar";

    @Before
    public void init() throws InterruptedException {
        this.promise = new UnaryPromise<>((resolve, reject) -> {
            this.resolve = resolve;
            this.reject = reject;
        });
        this.promise2 = new UnaryPromise<>((resolve, reject) -> {
            this.resolve2 = resolve;
            this.reject2 = reject;
        });

        Thread.sleep(50);
    }

    @Test
    public void testThenSetsConsumer() {
        promise.then(consumer);
        List<UnaryConsumer> actual = Whitebox.getInternalState(promise, "resolves");

        List<UnaryConsumer> expected = new ArrayList<>();
        expected.add(consumer);

        assertThat(actual, is(expected));
    }

    @Test
    public void testExceptSetsConsumer() {
        promise.except(consumer);
        List<UnaryConsumer> actual = Whitebox.getInternalState(promise, "rejects");

        List<UnaryConsumer> expected = new ArrayList<>();
        expected.add(consumer);

        assertThat(actual, is(expected));
    }

    @Test
    public void testResolveRunsThen() {
        promise.then(consumer);
        resolve.call(message);

        verify(consumer, times(1)).call(message);
    }

    @Test
    public void testResolveRunsAllThens() {
        promise.then(consumer);
        promise.then(consumer);
        resolve.call(message);

        verify(consumer, times(2)).call(message);
    }

    @Test
    public void testResolveRunsThenOnlyOnce() {
        promise.then(consumer);
        resolve.call(message);
        resolve.call(message);

        verify(consumer, times(1)).call(message);
    }

    @Test
    public void testResolveDoesNotRunExcept() {
        promise.except(consumer);
        resolve.call(message);

        verify(consumer, times(0)).call(any(String.class));
    }

    @Test
    public void testRejectRunsExcept() {
        promise.except(consumer);
        reject.call(message);

        verify(consumer, times(1)).call(message);
    }

    @Test
    public void testRejectRunsAllExcepts() {
        promise.except(consumer);
        promise.except(consumer);
        reject.call(message);

        verify(consumer, times(2)).call(message);
    }

    @Test
    public void testRejectRunsExceptOnlyOnce() {
        promise.except(consumer);
        reject.call(message);

        verify(consumer, times(1)).call(message);
    }

    @Test
    public void testRejectDoesNotRunThen() {
        promise.then(consumer);
        reject.call(message);

        verify(consumer, times(0)).call(any(String.class));
    }

    // UnaryPromise.all()
    @Test
    public void testAllSinglePromiseResolveRunsThen() throws InterruptedException {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(promise);

        UnaryPromise<Set<String>> all = UnaryPromise.all(promises);
        all.then(consumer);

        resolve.call(message);

        Set<String> arguments = new HashSet<>();
        arguments.add(message);

        Thread.sleep(20);
        verify(consumer, times(1)).call(arguments);
    }

    @Test
    public void testAllMultiplePromisesResolveRunsThen() throws InterruptedException {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        UnaryPromise<Set<String>> all = UnaryPromise.all(promises);
        all.then(consumer);

        resolve.call(message);
        resolve2.call(message);

        Set<String> arguments = new HashSet<>();
        arguments.add(message);
        arguments.add(message);

        Thread.sleep(20);
        verify(consumer, times(1)).call(arguments);
    }

    @Test
    public void testAllSinglePromiseResolveDoesNotRunExcept() {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(promise);

        UnaryPromise<Set<String>> all = UnaryPromise.all(promises);
        all.except(consumer);

        resolve.call(message);

        verify(consumer, times(0)).call(any(Set.class));
    }

    @Test
    public void testAllMultiplePromisesResolveDoesNotRunExcept() {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        UnaryPromise<Set<String>> all = UnaryPromise.all(promises);
        all.except(consumer);

        resolve.call(message);
        resolve2.call(message);

        verify(consumer, times(0)).call(any(Set.class));
    }

    @Test
    public void testAllSinglePromiseRejectRunsExcept() throws InterruptedException {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(promise);

        UnaryPromise<Set<String>> all = UnaryPromise.all(promises);
        all.except(consumer);

        reject.call(message);

        Set<String> arguments = new HashSet<>();
        arguments.add(message);

        Thread.sleep(20);
        verify(consumer, times(1)).call(arguments);
    }

    @Test
    public void testAllMultiplePromisesRejectRunsExcept() throws InterruptedException {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        UnaryPromise<Set<String>> all = UnaryPromise.all(promises);
        all.except(consumer);

        reject.call(message);
        reject2.call(message);

        Set<String> arguments = new HashSet<>();
        arguments.add(message);

        Thread.sleep(20);
        verify(consumer, times(1)).call(arguments);
    }

    @Test
    public void testAllSinglePromiseRejectDoesNotRunThen() {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(promise);

        UnaryPromise<Set<String>> all = UnaryPromise.all(promises);
        all.then(consumer);

        reject.call(message);

        verify(consumer, times(0)).call(any(Set.class));
    }

    @Test
    public void testAllMultiplePromiseRejectDoesNotRunThen() {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        UnaryPromise<Set<String>> all = UnaryPromise.all(promises);
        all.then(consumer);

        reject.call(message);
        reject2.call(message);

        verify(consumer, times(0)).call(any(Set.class));
    }

    @Test
    public void testAllMultiplePromisesOneResolvesOneRejectsRunsExcept() throws InterruptedException {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        UnaryPromise<Set<String>> all = UnaryPromise.all(promises);
        all.except(consumer);

        resolve.call(message);
        reject2.call(message);

        Set<String> arguments = new HashSet<>();
        arguments.add(message);

        Thread.sleep(20);
        verify(consumer, times(1)).call(arguments);
    }

    @Test
    public void testAllMultiplePromisesOneResolvesOneRejectsDoesNotRunThen() {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        UnaryPromise<Set<String>> all = UnaryPromise.all(promises);
        all.then(consumer);

        resolve.call(message);
        reject2.call(message);

        verify(consumer, times(0)).call(any(Set.class));
    }

    @Test
    public void testAllMultiplePromisesOneRejectsOneResolvesRunsExcept() throws InterruptedException {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        UnaryPromise<Set<String>> all = UnaryPromise.all(promises);
        all.except(consumer);

        reject.call(message);
        resolve2.call(message);

        Set<String> arguments = new HashSet<>();
        arguments.add(message);

        Thread.sleep(20);
        verify(consumer, times(1)).call(arguments);
    }

    @Test
    public void testAllMultiplePromisesOneRejectsOneResolvesDoesNotRunThen() {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        UnaryPromise<Set<String>> all = UnaryPromise.all(promises);
        all.then(consumer);

        reject.call(message);
        resolve2.call(message);

        verify(consumer, times(0)).call(any(Set.class));
    }

    // UnaryPromise.resolve()
    @Test
    public void testStaticResolveRunsThen() throws InterruptedException {
        UnaryPromise<String> promise = UnaryPromise.resolve(message);
        promise.then(consumer);

        Thread.sleep(20);
        verify(consumer, times(1)).call(message);
    }

    @Test
    public void testStaticResolveRunsAllThens() throws InterruptedException {
        UnaryPromise<String> promise = UnaryPromise.resolve(message);
        promise.then(consumer);
        promise.then(consumer);

        Thread.sleep(20);
        verify(consumer, times(2)).call(message);
    }

    @Test
    public void testStaticResolveDoesNotRunExcept() {
        UnaryPromise<String> promise = UnaryPromise.resolve(message);
        promise.except(consumer);

        verify(consumer, times(0)).call(any(String.class));
    }

    // UnaryPromise.reject()
    @Test
    public void testStaticRejectRunsExcept() throws InterruptedException {
        UnaryPromise<String> promise = UnaryPromise.reject(message);
        promise.except(consumer);

        Thread.sleep(20);
        verify(consumer, times(1)).call(message);
    }

    @Test
    public void testStaticRejectRunsAllExcepts() throws InterruptedException {
        UnaryPromise<String> promise = UnaryPromise.reject(message);
        promise.except(consumer);
        promise.except(consumer);

        Thread.sleep(20);
        verify(consumer, times(2)).call(message);
    }

    @Test
    public void testStaticRejectDoesNotRunThen() {
        UnaryPromise<String> promise = UnaryPromise.reject(message);
        promise.then(consumer);

        verify(consumer, times(0)).call(any(String.class));
    }

}
