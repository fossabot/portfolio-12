package promise;

import consumer.SimpleConsumer;

import org.junit.After;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertNull;
import static org.powermock.api.mockito.PowerMockito.mock;

public class AdvancedSimpleConsumerTest {

    SimpleConsumer consumer = mock(SimpleConsumer.class);
    SimpleConsumer consumer2 = mock(SimpleConsumer.class);
    SimpleConsumer task = mock(SimpleConsumer.class);

    @After
    public void tearDown() {
        AdvancedSimpleConsumer.tasks.clear();
        AdvancedSimpleConsumer.relations.clear();
    }

    @Test
    public void testAddPreRunTaskSingleSetsTask() {
        AdvancedSimpleConsumer.addPreRunTask(consumer, task);

        SimpleConsumer actual = AdvancedSimpleConsumer.tasks.get(consumer);
        assertThat(actual, is(task));
    }

    @Test
    public void testAddPreRunTaskDoubleSetsTaskFirst() {
        AdvancedSimpleConsumer.addPreRunTask(consumer, consumer2, task);

        SimpleConsumer actual = AdvancedSimpleConsumer.tasks.get(consumer);
        assertThat(actual, is(task));
    }

    @Test
    public void testAddPreRunTaskDoubleSetsTaskSecond() {
        AdvancedSimpleConsumer.addPreRunTask(consumer, consumer2, task);

        SimpleConsumer actual = AdvancedSimpleConsumer.tasks.get(consumer2);
        assertThat(actual, is(task));
    }

    @Test
    public void testAddPreRunTaskDoubleSetsRelation1to2() {
        AdvancedSimpleConsumer.addPreRunTask(consumer, consumer2, task);

        SimpleConsumer actual = AdvancedSimpleConsumer.relations.get(consumer);
        assertThat(actual, is(consumer2));
    }

    @Test
    public void testAddPreRunTaskDoubleSetsRelation2to1() {
        AdvancedSimpleConsumer.addPreRunTask(consumer, consumer2, task);

        SimpleConsumer actual = AdvancedSimpleConsumer.relations.get(consumer2);
        assertThat(actual, is(consumer));
    }

    @Test
    public void testRemovePreRunTaskRemovesTask() {
        AdvancedSimpleConsumer.tasks.put(consumer, task);

        AdvancedSimpleConsumer.removePreRunTask(consumer, task);

        SimpleConsumer actual = AdvancedSimpleConsumer.tasks.get(consumer);
        assertNull(actual);
    }

    @Test
    public void testRemovePreRunTaskDoesNotRemoveOtherTask() {
        AdvancedSimpleConsumer.tasks.put(consumer, task);
        AdvancedSimpleConsumer.tasks.put(consumer2, task);

        AdvancedSimpleConsumer.removePreRunTask(consumer, task);

        SimpleConsumer actual = AdvancedSimpleConsumer.tasks.get(consumer2);
        assertThat(actual, is(task));
    }

    @Test
    public void testRemovePreRunTaskRelationRemoveFirstRemovesFirst() {
        AdvancedSimpleConsumer.tasks.put(consumer, task);
        AdvancedSimpleConsumer.tasks.put(consumer2, task);
        AdvancedSimpleConsumer.relations.put(consumer, consumer2);
        AdvancedSimpleConsumer.relations.put(consumer2, consumer);

        AdvancedSimpleConsumer.removePreRunTask(consumer, task);

        SimpleConsumer actual = AdvancedSimpleConsumer.tasks.get(consumer);
        assertNull(actual);
    }

    @Test
    public void testRemovePreRunTaskRelationRemoveFirstRemovesSecond() {
        AdvancedSimpleConsumer.tasks.put(consumer, task);
        AdvancedSimpleConsumer.tasks.put(consumer2, task);
        AdvancedSimpleConsumer.relations.put(consumer, consumer2);
        AdvancedSimpleConsumer.relations.put(consumer2, consumer);

        AdvancedSimpleConsumer.removePreRunTask(consumer, task);

        SimpleConsumer actual = AdvancedSimpleConsumer.tasks.get(consumer2);
        assertNull(actual);
    }

    @Test
    public void testRemovePreRunTaskRelationRemoveSecondRemovesFirst() {
        AdvancedSimpleConsumer.tasks.put(consumer, task);
        AdvancedSimpleConsumer.tasks.put(consumer2, task);
        AdvancedSimpleConsumer.relations.put(consumer, consumer2);
        AdvancedSimpleConsumer.relations.put(consumer2, consumer);

        AdvancedSimpleConsumer.removePreRunTask(consumer2, task);

        SimpleConsumer actual = AdvancedSimpleConsumer.tasks.get(consumer);
        assertNull(actual);
    }

    @Test
    public void testRemovePreRunTaskRelationRemoveSecondRemovesSecond() {
        AdvancedSimpleConsumer.tasks.put(consumer, task);
        AdvancedSimpleConsumer.tasks.put(consumer2, task);
        AdvancedSimpleConsumer.relations.put(consumer, consumer2);
        AdvancedSimpleConsumer.relations.put(consumer2, consumer);

        AdvancedSimpleConsumer.removePreRunTask(consumer2, task);

        SimpleConsumer actual = AdvancedSimpleConsumer.tasks.get(consumer2);
        assertNull(actual);
    }

}
