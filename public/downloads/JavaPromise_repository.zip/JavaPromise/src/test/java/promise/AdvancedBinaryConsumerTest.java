package promise;

import consumer.BinaryConsumer;
import consumer.SimpleConsumer;

import org.junit.After;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertNull;
import static org.powermock.api.mockito.PowerMockito.mock;

public class AdvancedBinaryConsumerTest {

    BinaryConsumer consumer = mock(BinaryConsumer.class);
    BinaryConsumer consumer2 = mock(BinaryConsumer.class);
    SimpleConsumer task = mock(SimpleConsumer.class);

    @After
    public void tearDown() {
        AdvancedBinaryConsumer.tasks.clear();
        AdvancedBinaryConsumer.relations.clear();
    }

    @Test
    public void testAddPreRunTaskSingleSetsTask() {
        AdvancedBinaryConsumer.addPreRunTask(consumer, task);

        SimpleConsumer actual = AdvancedBinaryConsumer.tasks.get(consumer);
        assertThat(actual, is(task));
    }

    @Test
    public void testAddPreRunTaskDoubleSetsTaskFirst() {
        AdvancedBinaryConsumer.addPreRunTask(consumer, consumer2, task);

        SimpleConsumer actual = AdvancedBinaryConsumer.tasks.get(consumer);
        assertThat(actual, is(task));
    }

    @Test
    public void testAddPreRunTaskDoubleSetsTaskSecond() {
        AdvancedBinaryConsumer.addPreRunTask(consumer, consumer2, task);

        SimpleConsumer actual = AdvancedBinaryConsumer.tasks.get(consumer2);
        assertThat(actual, is(task));
    }

    @Test
    public void testAddPreRunTaskDoubleSetsRelation1to2() {
        AdvancedBinaryConsumer.addPreRunTask(consumer, consumer2, task);

        BinaryConsumer actual = AdvancedBinaryConsumer.relations.get(consumer);
        assertThat(actual, is(consumer2));
    }

    @Test
    public void testAddPreRunTaskDoubleSetsRelation2to1() {
        AdvancedBinaryConsumer.addPreRunTask(consumer, consumer2, task);

        BinaryConsumer actual = AdvancedBinaryConsumer.relations.get(consumer2);
        assertThat(actual, is(consumer));
    }

    @Test
    public void testRemovePreRunTaskRemovesTask() {
        AdvancedBinaryConsumer.tasks.put(consumer, task);

        AdvancedBinaryConsumer.removePreRunTask(consumer, task);

        SimpleConsumer actual = AdvancedBinaryConsumer.tasks.get(consumer);
        assertNull(actual);
    }

    @Test
    public void testRemovePreRunTaskDoesNotRemoveOtherTask() {
        AdvancedBinaryConsumer.tasks.put(consumer, task);
        AdvancedBinaryConsumer.tasks.put(consumer2, task);

        AdvancedBinaryConsumer.removePreRunTask(consumer, task);

        SimpleConsumer actual = AdvancedBinaryConsumer.tasks.get(consumer2);
        assertThat(actual, is(task));
    }

    @Test
    public void testRemovePreRunTaskRelationRemoveFirstRemovesFirst() {
        AdvancedBinaryConsumer.tasks.put(consumer, task);
        AdvancedBinaryConsumer.tasks.put(consumer2, task);
        AdvancedBinaryConsumer.relations.put(consumer, consumer2);
        AdvancedBinaryConsumer.relations.put(consumer2, consumer);

        AdvancedBinaryConsumer.removePreRunTask(consumer, task);

        SimpleConsumer actual = AdvancedBinaryConsumer.tasks.get(consumer);
        assertNull(actual);
    }

    @Test
    public void testRemovePreRunTaskRelationRemoveFirstRemovesSecond() {
        AdvancedBinaryConsumer.tasks.put(consumer, task);
        AdvancedBinaryConsumer.tasks.put(consumer2, task);
        AdvancedBinaryConsumer.relations.put(consumer, consumer2);
        AdvancedBinaryConsumer.relations.put(consumer2, consumer);

        AdvancedBinaryConsumer.removePreRunTask(consumer, task);

        SimpleConsumer actual = AdvancedBinaryConsumer.tasks.get(consumer2);
        assertNull(actual);
    }

    @Test
    public void testRemovePreRunTaskRelationRemoveSecondRemovesFirst() {
        AdvancedBinaryConsumer.tasks.put(consumer, task);
        AdvancedBinaryConsumer.tasks.put(consumer2, task);
        AdvancedBinaryConsumer.relations.put(consumer, consumer2);
        AdvancedBinaryConsumer.relations.put(consumer2, consumer);

        AdvancedBinaryConsumer.removePreRunTask(consumer2, task);

        SimpleConsumer actual = AdvancedBinaryConsumer.tasks.get(consumer);
        assertNull(actual);
    }

    @Test
    public void testRemovePreRunTaskRelationRemoveSecondRemovesSecond() {
        AdvancedBinaryConsumer.tasks.put(consumer, task);
        AdvancedBinaryConsumer.tasks.put(consumer2, task);
        AdvancedBinaryConsumer.relations.put(consumer, consumer2);
        AdvancedBinaryConsumer.relations.put(consumer2, consumer);

        AdvancedBinaryConsumer.removePreRunTask(consumer2, task);

        SimpleConsumer actual = AdvancedBinaryConsumer.tasks.get(consumer2);
        assertNull(actual);
    }

}
