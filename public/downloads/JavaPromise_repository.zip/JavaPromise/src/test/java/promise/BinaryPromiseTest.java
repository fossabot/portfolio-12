package promise;

import consumer.BinaryConsumer;
import consumer.UnaryConsumer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import util.Pair;

import org.junit.Before;
import org.junit.Test;
import org.powermock.reflect.Whitebox;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.mock;

@SuppressWarnings("unchecked") // Needed for Consumer mock
public class BinaryPromiseTest {

    private BinaryConsumer consumer = mock(BinaryConsumer.class);
    private UnaryConsumer uConsumer = mock(UnaryConsumer.class);

    private BinaryPromise<String, String> promise;
    private BinaryConsumer resolve;
    private BinaryConsumer reject;

    private BinaryPromise<String, String> promise2;
    private BinaryConsumer resolve2;
    private BinaryConsumer reject2;

    private String message1 = "foo";
    private String message2 = "bar";

    @Before
    public void init() throws InterruptedException {
        this.promise = new BinaryPromise<>((resolve, reject) -> {
            this.resolve = resolve;
            this.reject = reject;
        });
        this.promise2 = new BinaryPromise<>((resolve, reject) -> {
            this.resolve2 = resolve;
            this.reject2 = reject;
        });

        Thread.sleep(50);
    }

    @Test
    public void testThenSetsConsumer() {
        promise.then(consumer);
        List<BinaryConsumer> actual = Whitebox.getInternalState(promise, "resolves");

        List<BinaryConsumer> expected = new ArrayList<>();
        expected.add(consumer);

        assertThat(actual, is(expected));
    }

    @Test
    public void testExceptSetsConsumer() {
        promise.except(consumer);
        List<BinaryConsumer> actual = Whitebox.getInternalState(promise, "rejects");

        List<BinaryConsumer> expected = new ArrayList<>();
        expected.add(consumer);

        assertThat(actual, is(expected));
    }

    @Test
    public void testResolveRunsThen() {
        promise.then(consumer);
        resolve.call(message1, message2);

        verify(consumer, times(1)).call(message1, message2);
    }

    @Test
    public void testResolveRunsAllThens() {
        promise.then(consumer);
        promise.then(consumer);
        resolve.call(message1, message2);

        verify(consumer, times(2)).call(message1, message2);
    }

    @Test
    public void testResolveRunsThenOnlyOnce() {
        promise.then(consumer);
        resolve.call(message1, message2);
        resolve.call(message1, message2);

        verify(consumer, times(1)).call(message1, message2);
    }

    @Test
    public void testResolveDoesNotRunExcept() {
        promise.except(consumer);
        resolve.call(message1, message2);

        verify(consumer, times(0)).call(message1, message2);
    }

    @Test
    public void testRejectRunsExcept() {
        promise.except(consumer);
        reject.call(message1, message2);

        verify(consumer, times(1)).call(message1, message2);
    }

    @Test
    public void testRejectRunsAllExcepts() {
        promise.except(consumer);
        promise.except(consumer);
        reject.call(message1, message2);

        verify(consumer, times(2)).call(message1, message2);
    }

    @Test
    public void testRejectRunsExceptOnlyOnce() {
        promise.except(consumer);
        reject.call(message1, message2);
        reject.call(message1, message2);

        verify(consumer, times(1)).call(message1, message2);
    }

    @Test
    public void testRejectDoesNotRunThen() {
        promise.then(consumer);
        reject.call(message1, message2);

        verify(consumer, times(0)).call(message1, message2);
    }

    // SimplePromise.all()
    @Test
    public void testAllSinglePromiseResolveRunsThen() throws InterruptedException {
        List<BinaryPromise<String, String>> promises = new ArrayList<>();
        promises.add(promise);

        UnaryPromise<Set<Pair<String, String>>> all = BinaryPromise.all(promises);
        all.then(uConsumer);

        resolve.call(message1, message2);

        Set<Pair<String, String>> arguments = new HashSet<>();
        arguments.add(new Pair(message1, message2));

        Thread.sleep(20);
        verify(uConsumer, times(1)).call(arguments);
    }

    @Test
    public void testAllMultiplePromisesResolveRunsThen() throws InterruptedException {
        List<BinaryPromise<String, String>> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        UnaryPromise<Set<Pair<String, String>>> all = BinaryPromise.all(promises);
        all.then(uConsumer);

        resolve.call(message1, message2);
        resolve2.call(message1, message2);

        Set<Pair<String, String>> arguments = new HashSet<>();
        arguments.add(new Pair(message1, message2));
        arguments.add(new Pair(message1, message2));

        Thread.sleep(20);
        verify(uConsumer, times(1)).call(arguments);
    }

    @Test
    public void testAllSinglePromiseResolveDoesNotRunExcept() {
        List<BinaryPromise<String, String>> promises = new ArrayList<>();
        promises.add(promise);

        UnaryPromise<Set<Pair<String, String>>> all = BinaryPromise.all(promises);
        all.except(uConsumer);

        resolve.call(message1, message2);

        verify(uConsumer, times(0)).call(any(Set.class));
    }

    @Test
    public void testAllMultiplePromisesResolveDoesNotRunExcept() {
        List<BinaryPromise<String, String>> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        UnaryPromise<Set<Pair<String, String>>> all = BinaryPromise.all(promises);
        all.except(uConsumer);

        resolve.call(message1, message2);
        resolve2.call(message1, message2);

        verify(uConsumer, times(0)).call(any(Set.class));
    }

    @Test
    public void testAllSinglePromiseRejectRunsExcept() throws InterruptedException {
        List<BinaryPromise<String, String>> promises = new ArrayList<>();
        promises.add(promise);

        UnaryPromise<Set<Pair<String, String>>> all = BinaryPromise.all(promises);
        all.except(uConsumer);

        reject.call(message1, message2);

        Set<Pair<String, String>> arguments = new HashSet<>();
        arguments.add(new Pair(message1, message2));

        Thread.sleep(20);
        verify(uConsumer, times(1)).call(arguments);
    }

    @Test
    public void testAllMultiplePromisesRejectRunsExcept() throws InterruptedException {
        List<BinaryPromise<String, String>> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        UnaryPromise<Set<Pair<String, String>>> all = BinaryPromise.all(promises);
        all.except(uConsumer);

        reject.call(message1, message2);
        reject2.call(message1, message2);

        Set<Pair<String, String>> arguments = new HashSet<>();
        arguments.add(new Pair(message1, message2));

        Thread.sleep(20);
        verify(uConsumer, times(1)).call(arguments);
    }

    @Test
    public void testAllSinglePromiseRejectDoesNotRunThen() {
        List<BinaryPromise<String, String>> promises = new ArrayList<>();
        promises.add(promise);

        UnaryPromise<Set<Pair<String, String>>> all = BinaryPromise.all(promises);
        all.then(uConsumer);

        reject.call(message1, message2);

        verify(uConsumer, times(0)).call(any(Set.class));
    }

    @Test
    public void testAllMultiplePromiseRejectDoesNotRunThen() {
        List<BinaryPromise<String, String>> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        UnaryPromise<Set<Pair<String, String>>> all = BinaryPromise.all(promises);
        all.then(uConsumer);

        reject.call(message1, message2);
        reject2.call(message1, message2);

        verify(uConsumer, times(0)).call(any(Set.class));
    }

    @Test
    public void testAllMultiplePromisesOneResolvesOneRejectsRunsExcept() throws InterruptedException {
        List<BinaryPromise<String, String>> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        UnaryPromise<Set<Pair<String, String>>> all = BinaryPromise.all(promises);
        all.except(uConsumer);

        resolve.call(message1, message2);
        reject2.call(message1, message2);

        Set<Pair<String, String>> arguments = new HashSet<>();
        arguments.add(new Pair(message1, message2));

        Thread.sleep(20);
        verify(uConsumer, times(1)).call(arguments);
    }

    @Test
    public void testAllMultiplePromisesOneResolvesOneRejectsDoesNotRunThen() {
        List<BinaryPromise<String, String>> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        UnaryPromise<Set<Pair<String, String>>> all = BinaryPromise.all(promises);
        all.then(uConsumer);

        resolve.call(message1, message2);
        reject2.call(message1, message2);

        verify(uConsumer, times(0)).call(any(Set.class));
    }

    @Test
    public void testAllMultiplePromisesOneRejectsOneResolvesRunsExcept() throws InterruptedException {
        List<BinaryPromise<String, String>> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        UnaryPromise<Set<Pair<String, String>>> all = BinaryPromise.all(promises);
        all.except(uConsumer);

        reject.call(message1, message2);
        resolve2.call(message1, message2);

        Set<Pair<String, String>> arguments = new HashSet<>();
        arguments.add(new Pair(message1, message2));

        Thread.sleep(20);
        verify(uConsumer, times(1)).call(arguments);
    }

    @Test
    public void testAllMultiplePromisesOneRejectsOneResolvesDoesNotRunThen() {
        List<BinaryPromise<String, String>> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        UnaryPromise<Set<Pair<String, String>>> all = BinaryPromise.all(promises);
        all.then(uConsumer);

        reject.call(message1, message2);
        resolve2.call(message1, message2);

        verify(uConsumer, times(0)).call(any(Set.class));
    }

    // BinaryPromise.resolve()
    @Test
    public void testStaticResolveRunsThen() throws InterruptedException {
        BinaryPromise<String, String> promise = BinaryPromise.resolve(message1, message2);
        promise.then(consumer);

        Thread.sleep(20);
        verify(consumer, times(1)).call(message1, message2);
    }

    @Test
    public void testStaticResolveRunsAllThens() throws InterruptedException {
        BinaryPromise<String, String> promise = BinaryPromise.resolve(message1, message2);
        promise.then(consumer);
        promise.then(consumer);

        Thread.sleep(20);
        verify(consumer, times(2)).call(message1, message2);
    }

    @Test
    public void testStaticResolveDoesNotRunExcept() {
        BinaryPromise<String, String> promise = BinaryPromise.resolve(message1, message2);
        promise.except(consumer);

        verify(consumer, times(0)).call(message1, message2);
    }

    // BinaryPromise.reject()
    @Test
    public void testStaticRejectRunsExcept() throws InterruptedException {
        BinaryPromise<String, String> promise = BinaryPromise.reject(message1, message2);
        promise.except(consumer);

        Thread.sleep(20);
        verify(consumer, times(1)).call(message1, message2);
    }

    @Test
    public void testStaticRejectRunsAllExcepts() throws InterruptedException {
        BinaryPromise<String, String> promise = BinaryPromise.reject(message1, message2);
        promise.except(consumer);
        promise.except(consumer);

        Thread.sleep(20);
        verify(consumer, times(2)).call(message1, message2);
    }

    @Test
    public void testStaticRejectDoesNotRunThen() {
        BinaryPromise<String, String> promise = BinaryPromise.reject(message1, message2);
        promise.then(consumer);

        verify(consumer, times(0)).call(message1, message2);
    }

}
