package promise;

import consumer.SimpleConsumer;
import consumer.UnaryConsumer;

import org.junit.After;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertNull;
import static org.powermock.api.mockito.PowerMockito.mock;

public class AdvancedUnaryConsumerTest {

    UnaryConsumer consumer = mock(UnaryConsumer.class);
    UnaryConsumer consumer2 = mock(UnaryConsumer.class);
    SimpleConsumer task = mock(SimpleConsumer.class);

    @After
    public void tearDown() {
        AdvancedUnaryConsumer.tasks.clear();
        AdvancedUnaryConsumer.relations.clear();
    }

    @Test
    public void testAddPreRunTaskSingleSetsTask() {
        AdvancedUnaryConsumer.addPreRunTask(consumer, task);

        SimpleConsumer actual = AdvancedUnaryConsumer.tasks.get(consumer);
        assertThat(actual, is(task));
    }

    @Test
    public void testAddPreRunTaskDoubleSetsTaskFirst() {
        AdvancedUnaryConsumer.addPreRunTask(consumer, consumer2, task);

        SimpleConsumer actual = AdvancedUnaryConsumer.tasks.get(consumer);
        assertThat(actual, is(task));
    }

    @Test
    public void testAddPreRunTaskDoubleSetsTaskSecond() {
        AdvancedUnaryConsumer.addPreRunTask(consumer, consumer2, task);

        SimpleConsumer actual = AdvancedUnaryConsumer.tasks.get(consumer2);
        assertThat(actual, is(task));
    }

    @Test
    public void testAddPreRunTaskDoubleSetsRelation1to2() {
        AdvancedUnaryConsumer.addPreRunTask(consumer, consumer2, task);

        UnaryConsumer actual = AdvancedUnaryConsumer.relations.get(consumer);
        assertThat(actual, is(consumer2));
    }

    @Test
    public void testAddPreRunTaskDoubleSetsRelation2to1() {
        AdvancedUnaryConsumer.addPreRunTask(consumer, consumer2, task);

        UnaryConsumer actual = AdvancedUnaryConsumer.relations.get(consumer2);
        assertThat(actual, is(consumer));
    }

    @Test
    public void testRemovePreRunTaskRemovesTask() {
        AdvancedUnaryConsumer.tasks.put(consumer, task);

        AdvancedUnaryConsumer.removePreRunTask(consumer, task);

        SimpleConsumer actual = AdvancedUnaryConsumer.tasks.get(consumer);
        assertNull(actual);
    }

    @Test
    public void testRemovePreRunTaskDoesNotRemoveOtherTask() {
        AdvancedUnaryConsumer.tasks.put(consumer, task);
        AdvancedUnaryConsumer.tasks.put(consumer2, task);

        AdvancedUnaryConsumer.removePreRunTask(consumer, task);

        SimpleConsumer actual = AdvancedUnaryConsumer.tasks.get(consumer2);
        assertThat(actual, is(task));
    }

    @Test
    public void testRemovePreRunTaskRelationRemoveFirstRemovesFirst() {
        AdvancedUnaryConsumer.tasks.put(consumer, task);
        AdvancedUnaryConsumer.tasks.put(consumer2, task);
        AdvancedUnaryConsumer.relations.put(consumer, consumer2);
        AdvancedUnaryConsumer.relations.put(consumer2, consumer);

        AdvancedUnaryConsumer.removePreRunTask(consumer, task);

        SimpleConsumer actual = AdvancedUnaryConsumer.tasks.get(consumer);
        assertNull(actual);
    }

    @Test
    public void testRemovePreRunTaskRelationRemoveFirstRemovesSecond() {
        AdvancedUnaryConsumer.tasks.put(consumer, task);
        AdvancedUnaryConsumer.tasks.put(consumer2, task);
        AdvancedUnaryConsumer.relations.put(consumer, consumer2);
        AdvancedUnaryConsumer.relations.put(consumer2, consumer);

        AdvancedUnaryConsumer.removePreRunTask(consumer, task);

        SimpleConsumer actual = AdvancedUnaryConsumer.tasks.get(consumer2);
        assertNull(actual);
    }

    @Test
    public void testRemovePreRunTaskRelationRemoveSecondRemovesFirst() {
        AdvancedUnaryConsumer.tasks.put(consumer, task);
        AdvancedUnaryConsumer.tasks.put(consumer2, task);
        AdvancedUnaryConsumer.relations.put(consumer, consumer2);
        AdvancedUnaryConsumer.relations.put(consumer2, consumer);

        AdvancedUnaryConsumer.removePreRunTask(consumer2, task);

        SimpleConsumer actual = AdvancedUnaryConsumer.tasks.get(consumer);
        assertNull(actual);
    }

    @Test
    public void testRemovePreRunTaskRelationRemoveSecondRemovesSecond() {
        AdvancedUnaryConsumer.tasks.put(consumer, task);
        AdvancedUnaryConsumer.tasks.put(consumer2, task);
        AdvancedUnaryConsumer.relations.put(consumer, consumer2);
        AdvancedUnaryConsumer.relations.put(consumer2, consumer);

        AdvancedUnaryConsumer.removePreRunTask(consumer2, task);

        SimpleConsumer actual = AdvancedUnaryConsumer.tasks.get(consumer2);
        assertNull(actual);
    }

}
