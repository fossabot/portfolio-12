package promise;

import consumer.SimpleConsumer;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.powermock.reflect.Whitebox;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.mock;

public class SimplePromiseTest {

    private SimpleConsumer consumer = mock(SimpleConsumer.class);

    private SimplePromise promise;
    private SimpleConsumer resolve;
    private SimpleConsumer reject;

    private SimplePromise promise2;
    private SimpleConsumer resolve2;
    private SimpleConsumer reject2;

    @Before
    public void init() throws InterruptedException {
        this.promise = new SimplePromise((resolve, reject) -> {
            this.resolve = resolve;
            this.reject = reject;
        });
        this.promise2 = new SimplePromise((resolve, reject) -> {
            this.resolve2 = resolve;
            this.reject2 = reject;
        });

        Thread.sleep(50);
    }

    @Test
    public void testThenSetsConsumer() {
        promise.then(consumer);
        List<SimpleConsumer> actual = Whitebox.getInternalState(promise, "resolves");

        List<SimpleConsumer> expected = new ArrayList<>();
        expected.add(consumer);

        assertThat(actual, is(expected));
    }

    @Test
    public void testExceptSetsConsumer() {
        promise.except(consumer);
        List<SimpleConsumer> actual = Whitebox.getInternalState(promise, "rejects");

        List<SimpleConsumer> expected = new ArrayList<>();
        expected.add(consumer);

        assertThat(actual, is(expected));
    }

    @Test
    public void testResolveRunsThen() {
        promise.then(consumer);
        resolve.call();

        verify(consumer, times(1)).call();
    }

    @Test
    public void testResolveRunsAllThens() {
        promise.then(consumer);
        promise.then(consumer);
        resolve.call();

        verify(consumer, times(2)).call();
    }

    @Test
    public void testResolveRunsThenOnlyOnce() {
        promise.then(consumer);
        resolve.call();
        resolve.call();

        verify(consumer, times(1)).call();
    }

    @Test
    public void testResolveDoesNotRunExcept() {
        promise.except(consumer);
        resolve.call();

        verify(consumer, times(0)).call();
    }

    @Test
    public void testRejectRunsExcept() {
        promise.except(consumer);
        reject.call();

        verify(consumer, times(1)).call();
    }

    @Test
    public void testRejectRunsAllExcepts() {
        promise.except(consumer);
        promise.except(consumer);
        reject.call();

        verify(consumer, times(2)).call();
    }

    @Test
    public void testRejectRunsExceptOnlyOnce() {
        promise.except(consumer);
        reject.call();
        reject.call();

        verify(consumer, times(1)).call();
    }

    @Test
    public void testRejectDoesNotRunThen() {
        promise.then(consumer);
        reject.call();

        verify(consumer, times(0)).call();
    }

    // SimplePromise.all()
    @Test
    public void testAllSinglePromiseResolveRunsThen() throws InterruptedException {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(promise);

        SimplePromise all = SimplePromise.all(promises);
        all.then(consumer);

        resolve.call();

        Thread.sleep(20);
        verify(consumer, times(1)).call();
    }

    @Test
    public void testAllMultiplePromisesResolveRunsThen() throws InterruptedException {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        SimplePromise all = SimplePromise.all(promises);
        all.then(consumer);

        resolve.call();
        resolve2.call();

        Thread.sleep(20);
        verify(consumer, times(1)).call();
    }

    @Test
    public void testAllSinglePromiseResolveDoesNotRunExcept() {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(promise);

        SimplePromise all = SimplePromise.all(promises);
        all.except(consumer);

        resolve.call();

        verify(consumer, times(0)).call();
    }

    @Test
    public void testAllMultiplePromisesResolveDoesNotRunExcept() {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        SimplePromise all = SimplePromise.all(promises);
        all.except(consumer);

        resolve.call();
        resolve2.call();

        verify(consumer, times(0)).call();
    }

    @Test
    public void testAllSinglePromiseRejectRunsExcept() throws InterruptedException {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(promise);

        SimplePromise all = SimplePromise.all(promises);
        all.except(consumer);

        reject.call();

        Thread.sleep(20);
        verify(consumer, times(1)).call();
    }

    @Test
    public void testAllMultiplePromisesRejectRunsExcept() throws InterruptedException {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        SimplePromise all = SimplePromise.all(promises);
        all.except(consumer);

        reject.call();
        reject2.call();

        Thread.sleep(20);
        verify(consumer, times(1)).call();
    }

    @Test
    public void testAllSinglePromiseRejectDoesNotRunThen() {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(promise);

        SimplePromise all = SimplePromise.all(promises);
        all.then(consumer);

        reject.call();

        verify(consumer, times(0)).call();
    }

    @Test
    public void testAllMultiplePromisesRejectDoesNotRunThen() {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        SimplePromise all = SimplePromise.all(promises);
        all.then(consumer);

        reject.call();
        reject2.call();

        verify(consumer, times(0)).call();
    }

    @Test
    public void testAllMultiplePromisesOneResolvesOneRejectsRunsExcept() throws InterruptedException {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        SimplePromise all = SimplePromise.all(promises);
        all.except(consumer);

        resolve.call();
        reject2.call();

        Thread.sleep(20);
        verify(consumer, times(1)).call();
    }

    @Test
    public void testAllMultiplePromisesOneResolvesOneRejectsDoesNotRunThen() {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        SimplePromise all = SimplePromise.all(promises);
        all.then(consumer);

        resolve.call();
        reject2.call();

        verify(consumer, times(0)).call();
    }

    @Test
    public void testAllMultiplePromisesOneRejectsOneResolvesRunsExcept() throws InterruptedException {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        SimplePromise all = SimplePromise.all(promises);
        all.except(consumer);

        reject.call();
        resolve2.call();

        Thread.sleep(20);
        verify(consumer, times(1)).call();
    }

    @Test
    public void testAllMultiplePromisesOneRejectsOneResolvesDoesNotRunThen() {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(promise);
        promises.add(promise2);

        SimplePromise all = SimplePromise.all(promises);
        all.then(consumer);

        reject.call();
        resolve2.call();

        verify(consumer, times(0)).call();
    }

    // SimplePromise.resolve()
    @Test
    public void testStaticResolveRunsThen() throws InterruptedException {
        SimplePromise promise = SimplePromise.resolve();
        promise.then(consumer);

        Thread.sleep(20);
        verify(consumer, times(1)).call();
    }

    @Test
    public void testStaticResolveRunsAllThens() throws InterruptedException {
        SimplePromise promise = SimplePromise.resolve();
        promise.then(consumer);
        promise.then(consumer);

        Thread.sleep(20);
        verify(consumer, times(2)).call();
    }

    @Test
    public void testStaticResolveDoesNotRunExcept() {
        SimplePromise promise = SimplePromise.resolve();
        promise.except(consumer);

        verify(consumer, times(0)).call();
    }

    // SimplePromise.reject()
    @Test
    public void testStaticRejectRunsExcept() throws InterruptedException {
        SimplePromise promise = SimplePromise.reject();
        promise.except(consumer);

        Thread.sleep(20);
        verify(consumer, times(1)).call();
    }

    @Test
    public void testStaticRejectRunsAllExcepts() throws InterruptedException {
        SimplePromise promise = SimplePromise.reject();
        promise.except(consumer);
        promise.except(consumer);

        Thread.sleep(20);
        verify(consumer, times(2)).call();
    }

    @Test
    public void testStaticRejectDoesNotRunThen() {
        SimplePromise promise = SimplePromise.reject();
        promise.then(consumer);

        verify(consumer, times(0)).call();
    }

}
