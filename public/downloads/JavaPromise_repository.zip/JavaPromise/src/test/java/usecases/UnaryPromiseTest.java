package usecases;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import promise.UnaryPromise;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class UnaryPromiseTest {

    @Test
    public void testResolveInsteadOfReject() {
        UnaryPromise<String> promise = simulateResolve();
        promise.then((arg) -> assertTrue(true));
        promise.except((arg) -> assertFalse(false));
    }

    @Test
    public void testRejectInsteadOfResolve() {
        UnaryPromise<String> promise = simulateReject();
        promise.then((arg) -> assertFalse(false));
        promise.except((arg) -> assertTrue(true));
    }

    @Test
    public void testResolveOrder() {
        final List<Object> l = new ArrayList<>();
        UnaryPromise<String> promise = simulateResolve();

        promise.then((arg) -> {
            l.add(arg);
            assertThat(l.size(), is(1));
        });
        promise.then((arg) -> {
            l.add(arg);
            assertThat(l.size(), is(2));
        });
    }

    @Test
    public void testRejectOrder() {
        final List<Object> l = new ArrayList<>();
        UnaryPromise<String> promise = simulateReject();

        promise.except((arg) -> {
            l.add(arg);
            assertThat(l.size(), is(1));
        });
        promise.except((arg) -> {
            l.add(arg);
            assertThat(l.size(), is(2));
        });
    }

    @Test
    public void testChainingThen() {
        simulateResolve()
            .then((arg) -> assertTrue(true))
            .then((arg) -> assertTrue(true));
    }

    @Test
    public void testChainingExcept() {
        simulateResolve()
            .except((arg) -> assertTrue(true))
            .except((arg) -> assertTrue(true));
    }

    @Test
    public void testChainingThenExcept() {
        simulateResolve()
            .then((arg) -> assertTrue(true))
            .except((arg) -> assertTrue(true));
    }

    @Test
    public void testChainingExceptThen() {
        simulateResolve()
            .except((arg) -> assertTrue(true))
            .then((arg) -> assertTrue(true));
    }

    @Test
    public void testGenericTypeThen() {
        new UnaryPromise<String>((resolve, reject) -> {
            (new Thread() {
                public void run() {
                    try {
                        Thread.sleep(20);
                        resolve.call("foo");
                    } catch(InterruptedException e) {
                        reject.call("bar");
                    }
                }
            }).start();
        }).then((arg) -> assertTrue(arg instanceof String));

        new UnaryPromise<Integer>((resolve, reject) -> {
            (new Thread() {
                public void run() {
                    try {
                        Thread.sleep(20);
                        resolve.call(1);
                    } catch(InterruptedException e) {
                        reject.call(2);
                    }
                }
            }).start();
        }).then((arg) -> assertTrue(arg instanceof Integer));
    }

    @Test
    public void testGenericTypeExcept() {
        new UnaryPromise<String>((resolve, reject) -> {
            (new Thread() {
                public void run() {
                    try {
                        Thread.sleep(20);
                        reject.call("bar");
                    } catch(InterruptedException e) {
                        resolve.call("foo");
                    }
                }
            }).start();
        }).except((arg) -> assertTrue(arg instanceof String));

        new UnaryPromise<Integer>((resolve, reject) -> {
            (new Thread() {
                public void run() {
                    try {
                        Thread.sleep(20);
                        reject.call(2);
                    } catch(InterruptedException e) {
                        resolve.call(1);
                    }
                }
            }).start();
        }).except((arg) -> assertTrue(arg instanceof Integer));
    }

    @Test
    public void testPromiseWithThreadResolves() throws InterruptedException {
        UnaryPromise<String> p = new UnaryPromise<String>((resolve, reject) -> {
            (new Thread() {
                public void run() {
                    try {
                        Thread.sleep(25);
                        resolve.call("foo");
                    } catch(InterruptedException e) {
                        reject.call("bar");
                    }
                }
            }).start();
        });

        p.then((argument) -> assertTrue(true));
        p.except((argument) -> assertTrue(false));

        Thread.sleep(50);
    }

    @Test
    public void testPromiseWithThreadRejects() throws InterruptedException {
        UnaryPromise<String> p = new UnaryPromise<String>((resolve, reject) -> {
            (new Thread() {
                public void run() {
                    try {
                        Thread.sleep(25);
                        reject.call("bar");
                    } catch(InterruptedException e) {
                        resolve.call("foo");
                    }
                }
            }).start();
        });

        p.then((argument) -> assertTrue(false));
        p.except((argument) -> assertTrue(true));

        Thread.sleep(50);
    }

    // UnaryPromise.all()
    @Test
    public void testAllResolveInsteadOfReject() {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateResolve());

        UnaryPromise<Set<String>> promise = UnaryPromise.all(promises);
        promise.then((arguments) -> assertTrue(true));
        promise.except((arguments) -> assertTrue(false));
    }

    @Test
    public void testAllRejectInsteadOfResolve() {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateReject());

        UnaryPromise<Set<String>> promise = UnaryPromise.all(promises);
        promise.then((arguments) -> assertTrue(false));
        promise.except((arguments) -> assertTrue(true));
    }

    @Test
    public void testAllResolveOrder() {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateResolve());

        final List<Integer> l = new ArrayList<>();
        UnaryPromise<Set<String>> promise = UnaryPromise.all(promises);

        promise.then((arguments) -> {
            l.add(1);
            assertThat(l.size(), is(1));
        });
        promise.then((arguments) -> {
            l.add(2);
            assertThat(l.size(), is(2));
        });
    }

    @Test
    public void testAllRejectOrder() {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateReject());

        final List<Integer> l = new ArrayList<>();
        UnaryPromise<Set<String>> promise = UnaryPromise.all(promises);

        promise.except((arguments) -> {
            l.add(1);
            assertThat(l.size(), is(1));
        });
        promise.except((arguments) -> {
            l.add(2);
            assertThat(l.size(), is(2));
        });
    }

    @Test
    public void testAllResolveChainingThen() {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateResolve());

        UnaryPromise.all(promises)
            .then((argument) -> assertTrue(true))
            .then((argument) -> assertTrue(true));
    }

    @Test
    public void testAllResolveChainingThenExcept() {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateResolve());

        UnaryPromise.all(promises)
            .then((argument) -> assertTrue(true))
            .except((argument) -> assertTrue(false));
    }

    @Test
    public void testAllResolveChainingExceptThen() {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateResolve());

        UnaryPromise.all(promises)
            .except((argument) -> assertTrue(false))
            .then((argument) -> assertTrue(true));
    }

    @Test
    public void testAllRejectChainingExcept() {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateReject());

        UnaryPromise.all(promises)
            .except((argument) -> assertTrue(true))
            .except((argument) -> assertTrue(true));
    }

    @Test
    public void testAllRejectChainingThenExcept() {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateReject());

        UnaryPromise.all(promises)
            .then((argument) -> assertTrue(false))
            .except((argument) -> assertTrue(true));
    }

    @Test
    public void testAllRejectChainingExceptThen() {
        List<UnaryPromise<String>> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateReject());

        UnaryPromise.all(promises)
            .except((argument) -> assertTrue(true))
            .then((argument) -> assertTrue(false));
    }

    // UnaryPromise.resolve()
    @Test
    public void testStaticResolveInsteadOfReject() {
        UnaryPromise<String> promise = UnaryPromise.resolve("foo");
        promise.then((arg) -> assertTrue(true));
        promise.except((arg) -> assertTrue(false));
    }

    @Test
    public void testStaticResolveOrder() {
        final List<Object> l = new ArrayList<>();
        UnaryPromise<String> promise = UnaryPromise.resolve("foo");

        promise.then((arg) -> {
            l.add(arg);
            assertThat(l.size(), is(1));
        });
        promise.then((arg) -> {
            l.add(arg);
            assertThat(l.size(), is(2));
        });
    }

    @Test
    public void testStaticResolveChainingThen() {
        UnaryPromise.resolve("foo")
            .then((arg) -> assertTrue(true))
            .then((arg) -> assertTrue(true));
    }

    @Test
    public void testStaticResolveChainingThenExcept() {
        UnaryPromise.resolve("foo")
            .then((arg) -> assertTrue(true))
            .except((arg) -> assertTrue(false));
    }

    @Test
    public void testStaticResolveChainingExceptThen() {
        UnaryPromise.resolve("foo")
            .except((arg) -> assertTrue(false))
            .then((arg) -> assertTrue(true));
    }

    @Test
    public void testStaticGenericTypeThen() {
        UnaryPromise.resolve("foobar")
            .then((arg) -> assertTrue(arg instanceof String));
        UnaryPromise.resolve(1)
            .then((arg) -> assertTrue(arg instanceof Integer));
    }

    // UnaryPromise.reject()
    @Test
    public void testStaticRejectInsteadOfResolve() {
        UnaryPromise<String> promise = UnaryPromise.reject("bar");
        promise.then((arg) -> assertTrue(false));
        promise.except((arg) -> assertTrue(true));
    }

    @Test
    public void testStaticRejectOrder() {
        final List<Object> l = new ArrayList<>();
        UnaryPromise<String> promise = UnaryPromise.reject("bar");

        promise.except((arg) -> {
            l.add(arg);
            assertThat(l.size(), is(1));
        });
        promise.except((arg) -> {
            l.add(arg);
            assertThat(l.size(), is(2));
        });
    }

    @Test
    public void testStaticRejectChainingExcept() {
        UnaryPromise.reject("bar")
            .except((arg) -> assertTrue(true))
            .except((arg) -> assertTrue(true));
    }

    @Test
    public void testStaticRejectChainingThenExcept() {
        UnaryPromise.reject("bar")
            .then((arg) -> assertTrue(false))
            .except((arg) -> assertTrue(true));
    }

    @Test
    public void testStaticRejectChainingExceptThen() {
        UnaryPromise.reject("bar")
            .except((arg) -> assertTrue(true))
            .then((arg) -> assertTrue(false));
    }

    @Test
    public void testStaticGenericTypeExcept() {
        UnaryPromise.reject("foobar")
            .except((arg) -> assertTrue(arg instanceof String));
        UnaryPromise.reject(1)
            .except((arg) -> assertTrue(arg instanceof Integer));
    }

    // Helper methods
    private UnaryPromise<String> simulateResolve() {
        return new UnaryPromise<String>((resolve, reject) -> resolve.call("foo"));
    }

    private UnaryPromise<String> simulateReject() {
        return new UnaryPromise<String>((resolve, reject) -> reject.call("bar"));
    }

}
