package usecases;

import java.util.ArrayList;
import java.util.List;
import promise.SimplePromise;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class SimplePromiseTest {

    @Test
    public void testResolveInsteadOfReject() {
        SimplePromise promise = simulateResolve();
        promise.then(() -> assertTrue(true));
        promise.except(() -> assertFalse(false));
    }

    @Test
    public void testRejectInsteadOfResolve() {
        SimplePromise promise = simulateReject();
        promise.then(() -> assertFalse(false));
        promise.except(() -> assertTrue(true));
    }

    @Test
    public void testResolveOrder() {
        final List<Integer> l = new ArrayList<>();
        SimplePromise promise = simulateResolve();

        promise.then(() -> {
            l.add(1);
            assertThat(l.size(), is(1));
        });
        promise.then(() -> {
            l.add(2);
            assertThat(l.size(), is(2));
        });
    }

    @Test
    public void testRejectOrder() {
        final List<Integer> l = new ArrayList<>();
        SimplePromise promise = simulateReject();

        promise.except(() -> {
            l.add(1);
            assertThat(l.size(), is(1));
        });
        promise.except(() -> {
            l.add(2);
            assertThat(l.size(), is(2));
        });
    }

    @Test
    public void testResolveChainingThen() {
        simulateResolve()
            .then(() -> assertTrue(true))
            .then(() -> assertTrue(true));
    }

    @Test
    public void testResolveChainingThenExcept() {
        simulateResolve()
            .then(() -> assertTrue(true))
            .except(() -> assertTrue(false));
    }

    @Test
    public void testResolveChainingExceptThen() {
        simulateResolve()
            .except(() -> assertTrue(false))
            .then(() -> assertTrue(true));
    }

    @Test
    public void testRejectChainingExcept() {
        simulateResolve()
            .except(() -> assertTrue(true))
            .except(() -> assertTrue(true));
    }

    @Test
    public void testRejectChainingThenExcept() {
        simulateReject()
            .then(() -> assertTrue(false))
            .except(() -> assertTrue(true));
    }

    @Test
    public void testRejectChainingExceptThen() {
        simulateReject()
            .except(() -> assertTrue(true))
            .then(() -> assertTrue(false));
    }

    /*@Test
    public void testPromiseWithThreadResolves() throws InterruptedException {
        SimplePromise p = new SimplePromise((resolve, reject) -> {
            (new Thread() {
                public void run() {
                    try {
                        Thread.sleep(25);
                        resolve.call();
                    } catch(InterruptedException e) {
                        reject.call();
                    }
                }
            }).start();
        });

        p.then(() -> assertTrue(true));
        p.except(() -> assertTrue(false));

        Thread.sleep(50);
    }

    @Test
    public void testPromiseWithThreadRejects() throws InterruptedException {
        SimplePromise p = new SimplePromise((resolve, reject) -> {
            (new Thread() {
                public void run() {
                    try {
                        Thread.sleep(25);
                        reject.call();
                    } catch(InterruptedException e) {
                        resolve.call();
                    }
                }
            }).start();
        });

        p.then(() -> assertTrue(false));
        p.except(() -> assertTrue(true));

        Thread.sleep(50);
    }*/

    // SimplePromise.all()
    @Test
    public void testAllResolveInsteadOfReject() {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateResolve());

        SimplePromise promise = SimplePromise.all(promises);
        promise.then(() -> assertTrue(true));
        promise.except(() -> assertTrue(false));
    }

    @Test
    public void testAllRejectInsteadOfResolve() {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateReject());

        SimplePromise promise = SimplePromise.all(promises);
        promise.then(() -> assertTrue(false));
        promise.except(() -> assertTrue(true));
    }

    @Test
    public void testAllResolveOrder() {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateResolve());

        final List<Integer> l = new ArrayList<>();
        SimplePromise promise = SimplePromise.all(promises);

        promise.then(() -> {
            l.add(1);
            assertThat(l.size(), is(1));
        });
        promise.then(() -> {
            l.add(2);
            assertThat(l.size(), is(2));
        });
    }

    @Test
    public void testAllRejectOrder() {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateReject());

        final List<Integer> l = new ArrayList<>();
        SimplePromise promise = SimplePromise.all(promises);

        promise.except(() -> {
            l.add(1);
            assertThat(l.size(), is(1));
        });
        promise.except(() -> {
            l.add(2);
            assertThat(l.size(), is(2));
        });
    }

    @Test
    public void testAllResolveChainingThen() {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateResolve());

        SimplePromise.all(promises)
            .then(() -> assertTrue(true))
            .then(() -> assertTrue(true));
    }

    @Test
    public void testAllResolveChainingThenExcept() {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateResolve());

        SimplePromise.all(promises)
            .then(() -> assertTrue(true))
            .except(() -> assertTrue(false));
    }

    @Test
    public void testAllResolveChainingExceptThen() {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateResolve());

        SimplePromise.all(promises)
            .except(() -> assertTrue(false))
            .then(() -> assertTrue(true));
    }

    @Test
    public void testAllRejectChainingExcept() {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateReject());

        SimplePromise.all(promises)
            .except(() -> assertTrue(true))
            .except(() -> assertTrue(true));
    }

    @Test
    public void testAllRejectChainingThenExcept() {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateReject());

        SimplePromise.all(promises)
            .then(() -> assertTrue(false))
            .except(() -> assertTrue(true));
    }

    @Test
    public void testAllRejectChainingExceptThen() {
        List<SimplePromise> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateReject());

        SimplePromise.all(promises)
            .except(() -> assertTrue(true))
            .then(() -> assertTrue(false));
    }

    // SimplePromise.resolve()
    @Test
    public void testStaticResolveInsteadOfReject() {
        SimplePromise promise = SimplePromise.resolve();
        promise.then(() -> assertTrue(true));
        promise.except(() -> assertTrue(false));
    }

    @Test
    public void testStaticResolveOrder() {
        final List<Integer> l = new ArrayList<>();
        SimplePromise promise = SimplePromise.resolve();

        promise.then(() -> {
            l.add(1);
            assertThat(l.size(), is(1));
        });
        promise.then(() -> {
            l.add(2);
            assertThat(l.size(), is(2));
        });
    }

    @Test
    public void testStaticResolveChainingThen() {
        SimplePromise.resolve()
            .then(() -> assertTrue(true))
            .then(() -> assertTrue(true));
    }

    @Test
    public void testStaticResolveChainingThenExcept() {
        SimplePromise.resolve()
            .then(() -> assertTrue(true))
            .except(() -> assertTrue(false));
    }

    @Test
    public void testStaticResolveChainingExceptThen() {
        SimplePromise.resolve()
            .except(() -> assertTrue(false))
            .then(() -> assertTrue(true));
    }

    // SimplePromise.reject()
    @Test
    public void testStaticRejectInsteadOfResolve() {
        SimplePromise promise = SimplePromise.reject();
        promise.then(() -> assertTrue(false));
        promise.except(() -> assertTrue(true));
    }

    @Test
    public void testStaticRejectOrder() {
        final List<Integer> l = new ArrayList<>();
        SimplePromise promise = SimplePromise.reject();

        promise.except(() -> {
            l.add(1);
            assertThat(l.size(), is(1));
        });
        promise.except(() -> {
            l.add(2);
            assertThat(l.size(), is(2));
        });
    }

    @Test
    public void testStaticRejectChainingExcept() {
        SimplePromise.reject()
            .except(() -> assertTrue(true))
            .except(() -> assertTrue(true));
    }

    @Test
    public void testStaticRejectChainingThenExcept() {
        SimplePromise.reject()
            .then(() -> assertTrue(false))
            .except(() -> assertTrue(true));
    }

    @Test
    public void testStaticRejectChainingExceptThen() {
        SimplePromise.reject()
            .except(() -> assertTrue(true))
            .then(() -> assertTrue(false));
    }

    // Helper methods
    private SimplePromise simulateResolve() {
        return new SimplePromise((resolve, reject) -> resolve.call());
    }

    private SimplePromise simulateReject() {
        return new SimplePromise((resolve, reject) -> reject.call());
    }

}
