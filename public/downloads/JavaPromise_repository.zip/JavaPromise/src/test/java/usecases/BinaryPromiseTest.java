package usecases;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import promise.BinaryPromise;
import promise.UnaryPromise;
import util.Pair;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class BinaryPromiseTest {

    @Test
    public void testResolveInsteadOfReject() {
        BinaryPromise<Integer, String> promise = simulateResolve();
        promise.then((integer, string) -> assertTrue(true));
        promise.except((integer, string) -> assertFalse(false));
    }

    @Test
    public void testRejectInsteadOfResolve() {
        BinaryPromise<Integer, String> promise = simulateReject();
        promise.then((integer, string) -> assertFalse(false));
        promise.except((integer, string) -> assertTrue(true));
    }

    @Test
    public void testResolveOrder() {
        final List<Object> texts = new ArrayList<>();
        BinaryPromise<Integer, String> promise = simulateResolve();

        promise.then((integer, string) -> {
            texts.add(integer);
            assertThat(texts.size(), is(1));
        });
        promise.then((integer, string) -> {
            texts.add(integer);
            assertThat(texts.size(), is(2));
        });
    }

    @Test
    public void testRejectOrder() {
        final List<Object> numbers = new ArrayList<>();
        BinaryPromise<Integer, String> promise = simulateReject();

        promise.except((integer, string) -> {
            numbers.add(integer);
            assertThat(numbers.size(), is(1));
        });
        promise.except((integer, string) -> {
            numbers.add(integer);
            assertThat(numbers.size(), is(2));
        });
    }

    @Test
    public void testChainingThen() {
        simulateResolve()
            .then((integer, string) -> assertTrue(true))
            .then((integer, string) -> assertTrue(true));
    }

    @Test
    public void testChainingExcept() {
        simulateResolve()
            .except((integer, string) -> assertTrue(true))
            .except((integer, string) -> assertTrue(true));
    }

    @Test
    public void testChainingThenExcept() {
        simulateResolve()
            .then((integer, string) -> assertTrue(true))
            .except((integer, string) -> assertTrue(true));
    }

    @Test
    public void testChainingExceptThen() {
        simulateResolve()
            .except((integer, string) -> assertTrue(true))
            .then((integer, string) -> assertTrue(true));
    }

    @Test
    public void testGenericTypesOneThen() {
        new BinaryPromise<String, Integer>((resolve, reject) -> {
            (new Thread() {
                public void run() {
                    try {
                        Thread.sleep(20);
                        resolve.call("foo", 1);
                    } catch(InterruptedException e) {
                        reject.call("bar", 2);
                    }
                }
            }).start();
        }).then((argOne, argTwo) -> assertTrue(argOne instanceof String));

        new BinaryPromise<Integer, String>((resolve, reject) -> {
            (new Thread() {
                public void run() {
                    try {
                        Thread.sleep(20);
                        resolve.call(1, "foo");
                    } catch(InterruptedException e) {
                        reject.call(2, "bar");
                    }
                }
            }).start();
        }).then((argOne, argTwo) -> assertTrue(argOne instanceof Integer));
    }

    @Test
    public void testGenericTypesTwoThen() {
        new BinaryPromise<String, Integer>((resolve, reject) -> {
            (new Thread() {
                public void run() {
                    try {
                        Thread.sleep(20);
                        resolve.call("foo", 1);
                    } catch(InterruptedException e) {
                        reject.call("bar", 2);
                    }
                }
            }).start();
        }).then((argOne, argTwo) -> assertTrue(argTwo instanceof Integer));

        new BinaryPromise<Integer, String>((resolve, reject) -> {
            (new Thread() {
                public void run() {
                    try {
                        Thread.sleep(20);
                        resolve.call(1, "foo");
                    } catch(InterruptedException e) {
                        reject.call(2, "bar");
                    }
                }
            }).start();
        }).then((argOne, argTwo) -> assertTrue(argTwo instanceof String));
    }

    @Test
    public void testGenericTypesOneExcept() {
        new BinaryPromise<String, Integer>((resolve, reject) -> {
            (new Thread() {
                public void run() {
                    try {
                        Thread.sleep(20);
                        reject.call("bar", 2);
                    } catch(InterruptedException e) {
                        resolve.call("foo", 1);
                    }
                }
            }).start();
        }).except((argOne, argTwo) -> assertTrue(argOne instanceof String));

        new BinaryPromise<Integer, String>((resolve, reject) -> {
            (new Thread() {
                public void run() {
                    try {
                        Thread.sleep(20);
                        reject.call(2, "bar");
                    } catch(InterruptedException e) {
                        resolve.call(1, "foo");
                    }
                }
            }).start();
        }).except((argOne, argTwo) -> assertTrue(argOne instanceof Integer));
    }

    @Test
    public void testGenericTypesTwoExcept() {
        new BinaryPromise<String, Integer>((resolve, reject) -> {
            (new Thread() {
                public void run() {
                    try {
                        Thread.sleep(20);
                        reject.call("bar", 2);
                    } catch(InterruptedException e) {
                        resolve.call("foo", 1);
                    }
                }
            }).start();
        }).except((argOne, argTwo) -> assertTrue(argTwo instanceof Integer));

        new BinaryPromise<Integer, String>((resolve, reject) -> {
            (new Thread() {
                public void run() {
                    try {
                        Thread.sleep(20);
                        reject.call(2, "bar");
                    } catch(InterruptedException e) {
                        resolve.call(1, "foo");
                    }
                }
            }).start();
        }).except((argOne, argTwo) -> assertTrue(argTwo instanceof String));
    }

    @Test
    public void testPromiseWithThreadResolves() throws InterruptedException {
        BinaryPromise<Integer, String> p = new BinaryPromise<>((resolve, reject) -> {
            (new Thread() {
                public void run() {
                    try {
                        Thread.sleep(25);
                        resolve.call(1, "foo");
                    } catch(InterruptedException e) {
                        reject.call(2, "bar");
                    }
                }
            }).start();
        });

        p.then((argOne, argTwo) -> assertTrue(true));
        p.except((argOne, argTwo) -> assertTrue(false));

        Thread.sleep(50);
    }

    @Test
    public void testPromiseWithThreadRejects() throws InterruptedException {
        BinaryPromise<Integer, String> p = new BinaryPromise<>((resolve, reject) -> {
            (new Thread() {
                public void run() {
                    try {
                        Thread.sleep(25);
                        reject.call(3, "foo");
                    } catch(InterruptedException e) {
                        resolve.call(4, "bar");
                    }
                }
            }).start();
        });

        p.then((argOne, argTwo) -> assertTrue(false));
        p.except((argOne, argTwo) -> assertTrue(true));

        Thread.sleep(50);
    }

    // BinaryPromise.all()
    @Test
    public void testAllResolveInsteadOfReject() {
        List<BinaryPromise<Integer, String>> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateResolve());

        UnaryPromise<Set<Pair<Integer, String>>> promise = BinaryPromise.all(promises);
        promise.then((arguments) -> assertTrue(true));
        promise.except((arguments) -> assertTrue(false));
    }

    @Test
    public void testAllRejectInsteadOfResolve() {
        List<BinaryPromise<Integer, String>> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateReject());

        UnaryPromise<Set<Pair<Integer, String>>> promise = BinaryPromise.all(promises);
        promise.then((arguments) -> assertTrue(false));
        promise.except((arguments) -> assertTrue(true));
    }

    @Test
    public void testAllResolveOrder() {
        List<BinaryPromise<Integer, String>> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateResolve());

        final List<Integer> l = new ArrayList<>();
        UnaryPromise<Set<Pair<Integer, String>>> promise = BinaryPromise.all(promises);

        promise.then((arguments) -> {
            l.add(1);
            assertThat(l.size(), is(1));
        });
        promise.then((arguments) -> {
            l.add(2);
            assertThat(l.size(), is(2));
        });
    }

    @Test
    public void testAllRejectOrder() {
        List<BinaryPromise<Integer, String>> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateReject());

        final List<Integer> l = new ArrayList<>();
        UnaryPromise<Set<Pair<Integer, String>>> promise = BinaryPromise.all(promises);

        promise.except((arguments) -> {
            l.add(1);
            assertThat(l.size(), is(1));
        });
        promise.except((arguments) -> {
            l.add(2);
            assertThat(l.size(), is(2));
        });
    }

    @Test
    public void testAllResolveChainingThen() {
        List<BinaryPromise<Integer, String>> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateResolve());

        BinaryPromise.all(promises)
            .then((argument) -> assertTrue(true))
            .then((argument) -> assertTrue(true));
    }

    @Test
    public void testAllResolveChainingThenExcept() {
        List<BinaryPromise<Integer, String>> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateResolve());

        BinaryPromise.all(promises)
            .then((argument) -> assertTrue(true))
            .except((argument) -> assertTrue(false));
    }

    @Test
    public void testAllResolveChainingExceptThen() {
        List<BinaryPromise<Integer, String>> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateResolve());

        BinaryPromise.all(promises)
            .except((argument) -> assertTrue(false))
            .then((argument) -> assertTrue(true));
    }

    @Test
    public void testAllRejectChainingExcept() {
        List<BinaryPromise<Integer, String>> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateReject());

        BinaryPromise.all(promises)
            .except((argument) -> assertTrue(true))
            .except((argument) -> assertTrue(true));
    }

    @Test
    public void testAllRejectChainingThenExcept() {
        List<BinaryPromise<Integer, String>> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateReject());

        BinaryPromise.all(promises)
            .then((argument) -> assertTrue(false))
            .except((argument) -> assertTrue(true));
    }

    @Test
    public void testAllRejectChainingExceptThen() {
        List<BinaryPromise<Integer, String>> promises = new ArrayList<>();
        promises.add(simulateResolve());
        promises.add(simulateReject());

        BinaryPromise.all(promises)
            .except((argument) -> assertTrue(true))
            .then((argument) -> assertTrue(false));
    }


    // BinaryPromise.resolve()
    @Test
    public void testStaticResolveInsteadOfReject() {
        BinaryPromise<Integer, String> promise = BinaryPromise.resolve(1, "foo");
        promise.then((argOne, argTwo) -> assertTrue(true));
        promise.except((argOne, argTwo) -> assertTrue(false));
    }

    @Test
    public void testStaticResolveOrder() {
        final List<Object> l = new ArrayList<>();
        BinaryPromise<Integer, String> promise = BinaryPromise.resolve(1, "foo");

        promise.then((argOne, argTwo) -> {
            l.add(argOne);
            assertThat(l.size(), is(1));
        });
        promise.then((argOne, argTwo) -> {
            l.add(argOne);
            assertThat(l.size(), is(2));
        });
    }

    @Test
    public void testStaticResolveChainingThen() {
        BinaryPromise.resolve(1, "foo")
            .then((argOne, argTwo) -> assertTrue(true))
            .then((argOne, argTwo) -> assertTrue(true));
    }

    @Test
    public void testStaticResolveChainingThenExcept() {
        BinaryPromise.resolve(1, "foo")
            .then((argOne, argTwo) -> assertTrue(true))
            .except((argOne, argTwo) -> assertTrue(false));
    }

    @Test
    public void testStaticResolveChainingExceptThen() {
        BinaryPromise.resolve(1, "foo")
            .except((argOne, argTwo) -> assertTrue(false))
            .then((argOne, argTwo) -> assertTrue(true));
    }

    @Test
    public void testStaticGenericTypeOneThen() {
        BinaryPromise.resolve(1, "foo")
            .then((argOne, argTwo) -> assertTrue(argOne instanceof Integer));
        BinaryPromise.resolve("foo", 1)
            .then((argOne, argTwo) -> assertTrue(argOne instanceof String));
    }

    @Test
    public void testStaticGenericTypeTwoThen() {
        BinaryPromise.resolve(1, "foo")
            .then((argOne, argTwo) -> assertTrue(argTwo instanceof String));
        BinaryPromise.resolve("foo", 1)
            .then((argOne, argTwo) -> assertTrue(argTwo instanceof Integer));
    }

    // BinaryPromise.reject()
    @Test
    public void testStaticRejectInsteadOfResolve() {
        BinaryPromise<Integer, String> promise = BinaryPromise.reject(2, "bar");
        promise.then((argOne, argTwo) -> assertTrue(false));
        promise.except((argOne, argTwo) -> assertTrue(true));
    }

    @Test
    public void testStaticRejectOrder() {
        final List<Object> l = new ArrayList<>();
        BinaryPromise<Integer, String> promise = BinaryPromise.reject(2, "bar");

        promise.except((argOne, argTwo) -> {
            l.add(argOne);
            assertThat(l.size(), is(1));
        });
        promise.except((argOne, argTwo) -> {
            l.add(argOne);
            assertThat(l.size(), is(2));
        });
    }

    @Test
    public void testStaticRejectChainingExcept() {
        BinaryPromise.reject(2, "bar")
            .except((argOne, argTwo) -> assertTrue(true))
            .except((argOne, argTwo) -> assertTrue(true));
    }

    @Test
    public void testStaticRejectChainingThenExcept() {
        BinaryPromise.reject(2, "bar")
            .then((argOne, argTwo) -> assertTrue(false))
            .except((argOne, argTwo) -> assertTrue(true));
    }

    @Test
    public void testStaticRejectChainingExceptThen() {
        BinaryPromise.reject(2, "bar")
            .except((argOne, argTwo) -> assertTrue(true))
            .then((argOne, argTwo) -> assertTrue(false));
    }

    @Test
    public void testStaticGenericTypeOneExcept() {
        BinaryPromise.reject(1, "foo")
            .except((argOne, argTwo) -> assertTrue(argOne instanceof Integer));
        BinaryPromise.reject("foo", 1)
            .except((argOne, argTwo) -> assertTrue(argOne instanceof String));
    }

    @Test
    public void testStaticGenericTypeTwoExcept() {
        BinaryPromise.reject(1, "foo")
            .except((argOne, argTwo) -> assertTrue(argTwo instanceof String));
        BinaryPromise.reject("foo", 1)
            .except((argOne, argTwo) -> assertTrue(argTwo instanceof Integer));
    }

    // Helper methods
    private BinaryPromise<Integer, String> simulateResolve() {
        return new BinaryPromise<Integer, String>((resolve, reject) -> resolve.call(1, "foo"));
    }

    private BinaryPromise<Integer, String> simulateReject() {
        return new BinaryPromise<Integer, String>((resolve, reject) -> reject.call(2, "bar"));
    }

}
